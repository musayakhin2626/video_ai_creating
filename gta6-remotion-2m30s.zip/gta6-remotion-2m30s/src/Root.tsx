import {Composition} from "remotion";
import {Gta6ViralVideo} from "./Gta6ViralVideo";
import {AUDIO_DURATION_SECONDS, FPS} from "./timeline";

export const Root = () => (
  <Composition
    id="Gta6ViralTikTok"
    component={Gta6ViralVideo}
    durationInFrames={Math.ceil(AUDIO_DURATION_SECONDS * FPS)}
    fps={FPS}
    width={1080}
    height={1920}
  />
);
