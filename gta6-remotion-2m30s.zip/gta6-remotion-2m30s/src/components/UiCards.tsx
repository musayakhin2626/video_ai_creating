import React, {useId} from 'react';
import {interpolate, spring} from 'remotion';

export type CardKind =
  | 'phone' | 'papers' | 'boxes' | 'router' | 'office' | 'school' | 'pizza'
  | 'shelves' | 'relationship' | 'keys' | 'dog' | 'sales' | 'chat' | 'scanner'
  | 'poll' | 'timer';

const ink = '#121024';
const white = '#FFF9F3';
const muted = '#B9ADC8';
const cyan = '#00F0FF';
const pink = '#FF2E93';
const green = '#4ADE80';
const gold = '#FFAD5A';
const red = '#FF3B30';
const bounds = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const grouped = (n: number) => Math.round(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ' ');

type TextProps = React.SVGProps<SVGTextElement> & {size?: number; center?: boolean};
const InkText: React.FC<TextProps> = ({size = 36, center, children, ...props}) => (
  <text
    fill={white}
    fontFamily="Inter, Arial, sans-serif"
    fontSize={size}
    fontWeight={900}
    textAnchor={center ? 'middle' : 'start'}
    {...props}
  >{children}</text>
);

const PhoneGlyph: React.FC<{color?: string}> = ({color = white}) => (
  <path
    d="M5 12 Q10 1 19 3 L29 15 Q31 19 25 25 L20 30 Q27 45 41 51 L46 44 Q51 38 55 42 L68 51 Q73 55 68 62 Q63 70 56 70 Q43 70 28 60 Q13 49 5 32 Q0 20 5 12Z"
    fill={color}
  />
);

const Carton: React.FC<{x: number; y: number; fill?: string; rotate?: number}> = ({
  x, y, fill = gold, rotate = 0,
}) => (
  <g transform={`translate(${x} ${y}) rotate(${rotate} 90 62)`} stroke="#291527" strokeWidth={4} strokeLinejoin="round">
    <path d="M0 35L92 0L184 32L97 73Z" fill="#FFE1B2" />
    <path d="M0 35V122L97 167V73Z" fill={fill} />
    <path d="M97 73L184 32V122L97 167Z" fill="#9D4D4A" />
    <path d="M62 12L148 49V78L126 88V58L37 22Z" fill="#FFDE97" stroke="none" opacity=".85" />
    <path d="M18 109L51 125M18 120L51 135" stroke="#703648" strokeWidth="5" />
  </g>
);

const Pad: React.FC<{x: number; y: number; scale?: number}> = ({x, y, scale = 1}) => (
  <g transform={`translate(${x} ${y}) scale(${scale})`}>
    <path d="M45 14H127C150 14 168 39 172 68L181 117C185 144 165 156 147 139L119 109H55L26 139C9 154 -10 141 -6 119L4 68C10 39 22 14 45 14Z" fill="#30243F" stroke="#100E1C" strokeWidth="5" />
    <path d="M21 66L37 66V51H50V66H65V79H50V94H37V79H21Z" fill="#BDADCC" />
    <circle cx="127" cy="52" r="8" fill={pink} />
    <circle cx="146" cy="71" r="8" fill={cyan} />
    <circle cx="127" cy="88" r="8" fill={green} />
    <circle cx="108" cy="71" r="8" fill={gold} />
    <path d="M75 29H102" stroke={cyan} strokeWidth="4" strokeLinecap="round" />
  </g>
);

const PulsePill: React.FC<{x: number; y: number; width: number; color: string; text: string}> = ({
  x, y, width, color, text,
}) => (
  <g>
    <rect x={x} y={y} width={width} height="44" rx="22" fill={color} fillOpacity=".12" stroke={color} strokeOpacity=".62" />
    <circle cx={x + 24} cy={y + 22} r="5" fill={color} />
    <InkText x={x + 41} y={y + 30} size={19} fill={color} letterSpacing="1.6">{text}</InkText>
  </g>
);

const Desk: React.FC<{x: number; y: number; school?: boolean}> = ({x, y, school}) => (
  <g transform={`translate(${x} ${y})`} stroke="#151022" strokeWidth="4">
    <path d="M18 47H140V112H117V69H39V112H18Z" fill="#443450" />
    <path d="M1 37L26 15H165L143 49H1Z" fill={school ? '#C58362' : '#87659A'} />
    {school
      ? <path d="M49 25L95 25L86 35L39 35Z" fill="#F1B7A5" strokeWidth="2" />
      : <><path d="M75 21L86 3L129 3L109 31H71Z" fill="#2D2E54" /><path d="M82 20L91 8H120L111 20Z" fill="#44D8C3" fillOpacity=".52" strokeWidth="0" /></>}
    <path d="M120 69H167V124H154V84H120Z" fill="#685578" />
  </g>
);

export const UiCards: React.FC<{
  kind: CardKind;
  frame: number;
  fps: number;
  variant?: number;
}> = ({kind, frame, fps, variant = 0}) => {
  const uid = useId().replace(/:/g, '');
  const edge = `${uid}-edge`;
  const base = `${uid}-base`;
  const charge = `${uid}-charge`;
  const exit = spring({frame, fps, config: {damping: 12, stiffness: 160}});
  const lift = interpolate(exit, [0, 1], [88, 0]);
  const state = interpolate(frame, [6, 72], [0, 1], bounds);
  const beat = Math.sin(frame * .24);
  const flap = (shift: number) => spring({frame: frame - shift, fps, config: {damping: 12, stiffness: 160}});

  const Panel: React.FC<{label: string; color?: string; children: React.ReactNode}> = ({label, color = cyan, children}) => (
    <g>
      <rect x="42" y="126" width="816" height="665" rx="40" fill="#0A0813" opacity=".72" />
      <rect x="42" y="109" width="816" height="665" rx="40" fill={`url(#${base})`} stroke={`url(#${edge})`} strokeWidth="3" />
      <path d="M66 183H834M66 723H834" stroke="#72617C" strokeOpacity=".38" />
      <path d="M76 185H200" stroke={color} strokeWidth="4" strokeLinecap="round" />
      <circle cx="83" cy="148" r="6" fill={color} />
      <InkText x="108" y="157" size={26} fill={color} letterSpacing="2">{label}</InkText>
      <path d="M758 150h14m7 0h14m7 0h14" stroke="#C9ADDF" strokeWidth="4" strokeLinecap="round" opacity=".65" />
      {children}
      <path d="M79 746h29m8 0h11" stroke={color} strokeWidth="3" strokeLinecap="round" opacity=".8" />
    </g>
  );

  let content: React.ReactNode;
  switch (kind) {
    case 'phone': {
      const count = variant === 1 ? Math.min(20, 17 + Math.floor(state * 4)) : 20;
      const online = variant === 2 && frame > 39;
      const shake = beat * (variant > 0 ? 15 : 9);
      content = (
        <g transform={`translate(${shake} 0) rotate(${beat * 2.8 - 5} 450 440)`}>
          <path d="M154 355q-31 39 5 82m589-84q35 38 0 91M111 322q-55 71 4 142m681-145q58 69 0 142" fill="none" stroke={red} strokeWidth="7" strokeLinecap="round" opacity={.55 + beat * .24} />
          <rect x="189" y="42" width="522" height="800" rx="79" fill="#000" opacity=".63" />
          <rect x="189" y="24" width="522" height="800" rx="79" fill="#201A2E" stroke={`url(#${edge})`} strokeWidth="8" />
          <rect x="213" y="51" width="474" height="738" rx="57" fill={`url(#${base})`} stroke="#494058" strokeWidth="2" />
          <rect x="354" y="64" width="192" height="27" rx="13" fill="#080711" />
          <rect x="384" y="762" width="132" height="7" rx="4" fill="#A29BAC" />
          <circle cx="450" cy="228" r={86 + beat * 7} fill={red} fillOpacity=".09" stroke={red} strokeOpacity=".54" strokeWidth="2" />
          <circle cx="450" cy="228" r="61" fill={red} />
          <g transform="translate(421 198) scale(.83)"><PhoneGlyph /></g>
          <rect x="238" y="353" width="424" height="253" rx="23" fill={online ? '#153C36' : '#391D39'} stroke={online ? green : red} strokeWidth="4" />
          <InkText x="450" y="412" size={44} center fill={online ? green : '#FFBEBD'}>БОСС:</InkText>
          <InkText x="450" y="526" size={variant === 2 ? 68 : 110} center>{variant === 2 ? (online ? 'В ИГРЕ' : 'ВЫЗОВ') : count}</InkText>
          <InkText x="450" y="574" size={34} center fill={online ? green : '#FFBEBD'} letterSpacing="2">{variant === 2 ? (online ? 'ОНЛАЙН' : 'СРОЧНО В ОФИС') : 'ПРОПУЩЕННЫХ'}</InkText>
          <path d="M294 687H365M535 687H605" stroke="#6C526E" strokeWidth="4" strokeLinecap="round" />
          <circle cx="450" cy="686" r="39" fill={red} />
          <g transform="translate(414 673) scale(.57) rotate(43 35 35)"><PhoneGlyph /></g>
        </g>
      );
      break;
    }
    case 'papers': {
      const count = grouped(interpolate(frame, [9, Math.round(fps * 2.1)], [0, 10_000_000], bounds));
      const slam = flap(Math.round(fps * .48));
      content = (
        <g>
          {[0, 1, 2, 3, 4].map((i) => (
            <g key={i} transform={`translate(${76 + i * 125 + Math.sin(frame * .083 + i) * (16 + 25 * state)} ${95 + (i % 2) * 138 + Math.cos(frame * .068 + i) * 27 + state * (i + 1) * 39}) rotate(${-38 + i * 18 + state * (i - 2) * 13} 96 115)`}>
              <rect width="199" height="261" rx="13" fill={i % 2 ? '#D2C6E7' : '#F9E5DB'} stroke="#311F3B" strokeWidth="5" />
              <path d="M24 77H172M24 104H172M24 131H160M24 175H104M24 191H85" stroke="#746C91" strokeWidth="5" strokeLinecap="round" opacity=".6" />
              <InkText x="24" y="55" size={29} fill="#4C2C67">ОТГУЛ</InkText>
              <path d="M127 183l14 17 34-36" stroke={pink} strokeWidth="7" fill="none" strokeLinecap="round" />
            </g>
          ))}
          <g transform={`translate(450 308) rotate(-6) scale(${1 + Math.max(0, 1 - slam) * .65})`} opacity={Math.min(1, slam * 2)}>
            <rect x="-388" y="-69" width="776" height="138" rx="20" fill="#111F21" stroke={green} strokeWidth="9" />
            <rect x="-372" y="-53" width="744" height="106" rx="12" fill="none" stroke={green} strokeWidth="2" strokeDasharray="6 7" />
            <InkText x="0" y="18" size={60} center fill={green}>МИССИЯ ПРОЙДЕНА</InkText>
          </g>
          <rect x="93" y="504" width="714" height="224" rx="28" fill={`url(#${base})`} stroke={`url(#${edge})`} strokeWidth="3" />
          <InkText x="450" y="623" size={108} center>{count}</InkText>
          <InkText x="450" y="683" size={33} center fill={pink} letterSpacing="4">ПРЕДЗАКАЗОВ</InkText>
        </g>
      );
      break;
    }
    case 'boxes':
      content = variant > 0 ? (
        <Panel label="ПОСЛЕДНЯЯ КОРОБКА" color={gold}>
          <g transform={`translate(262 ${286 - Math.max(0, 1 - flap(3)) * 201})`} stroke="#291527" strokeWidth="4" strokeLinejoin="round">
            <path d="M0 122L201 32L381 114L202 231Z" fill="#63404F" />
            <path d="M0 122L202 231L381 114L381 234L202 327L0 227Z" fill="#C07358" />
            <path d="M202 231L381 114V234L202 327Z" fill="#8B4F55" />
            <path d="M46 127L191 66L332 119L198 194Z" fill="#EDE0D8" />
            <path d="M0 122L202 231L229 177L32 70Z" fill="#F1A46C" />
            <path transform={`translate(${flap(21) * 125} ${-flap(21) * 119}) rotate(${flap(21) * 21} 260 99)`} d="M202 231L381 114L267 49L66 148Z" fill="#E5A175" />
          </g>
          {Array.from({length: 18}, (_, i) => {
            const travel = interpolate(frame, [25 + i % 6, 85 + i % 9], [0, 1], bounds);
            const angle = i * 2.399;
            return <ellipse key={i} cx={450 + Math.cos(angle) * 343 * travel} cy={402 + Math.sin(angle) * 205 * travel - 83 * Math.sin(travel * Math.PI)} rx={8 + (i % 3) * 4} ry={5 + (i % 3) * 3} fill={white} opacity={travel === 0 ? 0 : 1 - travel * .4} />;
          })}
          <InkText x="450" y="682" center size={56}>ТОЛЬКО ПЕНОПЛАСТ</InkText>
        </Panel>
      ) : (
        <Panel label="НАГРУЗКА НА СЕРВЕР" color={gold}>
          <InkText x="450" y="278" center size={72}>ОЧЕРЕДЬ</InkText>
          <InkText x="450" y="326" center size={28} fill={muted}>ПОЗИЦИЯ {grouped(interpolate(state, [0, 1], [278_410, 176_842]))}</InkText>
          <path d="M153 644H748" stroke="#725D80" strokeWidth="4" strokeDasharray="9 13" />
          {[0, 1, 2, 3, 4].map((i) => (
            <Carton
              key={i}
              x={[139, 522, 327, 194, 492][i]}
              y={[469, 462, 491, 352, 358][i] - (1 - flap(6 + i * 7)) * 350}
              rotate={[-12, 14, -4, 9, -11][i]}
              fill={i % 2 ? '#F1A15D' : '#EAC08F'}
            />
          ))}
          <PulsePill x={279} y={660} width={335} color={gold} text="ВЫ В ОЧЕРЕДИ" />
        </Panel>
      );
      break;
    case 'router': {
      const percent = Math.floor(interpolate(frame, [0, 29], [91, 99.999], bounds));
      content = (
        <Panel label="ЗАГРУЗКА GTA 6" color={cyan}>
          <InkText x="450" y="344" size={152} center fill={percent === 99 ? pink : white}>{percent}%</InkText>
          <rect x="148" y="379" width="604" height="35" rx="17.5" fill="#302643" />
          <rect x="148" y="379" width={604 * percent / 100} height="35" rx="17.5" fill={`url(#${charge})`} />
          {Array.from({length: 8}, (_, i) => {
            const cycle = ((Math.max(0, frame - 16) + i * 10) % 84) / 84;
            return <ellipse key={i} cx={578 + Math.sin(i + cycle * 4) * 34 + cycle * 112} cy={522 - cycle * 177} rx={13 + cycle * 42} ry={12 + cycle * 19} opacity={frame < 16 ? 0 : (1 - cycle) * .31} fill="#C4A9D1" />;
          })}
          <path d="M230 554L205 450M668 554L698 450" stroke="#695477" strokeWidth="13" strokeLinecap="round" />
          <path d="M234 546H666L725 590H175Z" fill="#39314C" stroke="#0E0C1B" strokeWidth="5" />
          <rect x="175" y="586" width="550" height="62" rx="13" fill="#231C37" stroke="#0E0C1B" strokeWidth="5" />
          {[0, 1, 2, 3, 4, 5].map((i) => <path key={i} d={`M${278 + 64 * i} 560l-19 13`} stroke="#100F1B" strokeWidth="6" strokeLinecap="round" />)}
          {[0, 1, 2, 3].map((i) => <circle key={i} cx={217 + i * 26} cy="615" r="6" fill={i === 3 ? red : cyan} opacity={i === 3 ? .4 + Math.abs(beat) * .6 : .9} />)}
          <PulsePill x={270} y={664} width={365} color={red} text="СЕТЬ НЕ ОТВЕЧАЕТ" />
        </Panel>
      );
      break;
    }
    case 'office':
    case 'school': {
      const school = kind === 'school';
      content = (
        <Panel label={school ? 'УЧЁБА' : 'РАБОЧЕЕ УТРО'} color={school ? gold : cyan}>
          <rect x="118" y="222" width="665" height="338" rx="23" fill={school ? '#30283A' : '#202B49'} stroke="#69587E" strokeWidth="2" />
          <path d="M120 383H781V536Q781 558 759 558H140Q120 558 120 536Z" fill="#372841" />
          <path d="M448 383L169 555M448 383L725 555M157 463H735M139 505H765" stroke="#6B4A60" opacity=".59" strokeWidth="2" />
          {school ? (
            <g>
              <rect x="316" y="248" width="270" height="100" rx="5" fill="#173F44" stroke="#C08360" strokeWidth="6" />
              <path d="M340 273H432M340 296H507M340 320H417" stroke="#79CEC9" strokeOpacity=".57" strokeWidth="5" strokeLinecap="round" />
            </g>
          ) : (
            [211, 376, 541].map(x => <g key={x}><rect x={x} y="250" width="142" height="110" fill="#69528E" stroke="#A98BC5" strokeWidth="3" /><path d={`M${x + 71} 252V358M${x + 2} 310H${x + 141}`} stroke="#392D62" strokeWidth="4" /></g>)
          )}
          {[0, 1, 2, 3, 4, 5].map((i) => <Desk key={i} x={156 + (i % 3) * 201 + (i < 3 ? 10 : -7)} y={385 + Math.floor(i / 3) * 47} school={school} />)}
          {school ? Array.from({length: 7}, (_, i) => {
            const arrival = flap(9 + i * 7);
            const spread = 222 + i * 65;
            return (
              <g key={i} transform={`translate(${spread} ${300 - arrival * 46 + (i % 2) * 19}) rotate(${i * 4 - 19} 34 31)`} opacity={Math.min(1, arrival * 2)}>
                <rect width="66" height="82" rx="5" fill="#FFF0D8" stroke="#754B60" strokeWidth="2" />
                <path d="M12 29q10-17 20 1t22 0M12 43h40M12 55h26" fill="none" stroke="#625076" strokeWidth="3" strokeLinecap="round" />
              </g>
            );
          }) : frame > 23 && frame < 79 && (
            <g transform={`translate(${interpolate(frame, [24, 59, 79], [162, 476, 735], bounds)} ${408 + Math.sin(frame * .8) * 5})`}>
              <circle cy="-54" r="19" fill="#C8967C" stroke={ink} strokeWidth="3" />
              <path d="M-15-36Q0-47 15-36L22 5L8 11L9 31H-6L-11 10L-23 7Z" fill="#6AA6B6" stroke={ink} strokeWidth="3" />
              <path d="M12-24l20 18 40-7v16h9v-16h8" fill="none" stroke={gold} strokeWidth="5" strokeLinecap="round" />
            </g>
          )}
          <InkText x="450" y="637" center size={74} fill={school ? gold : cyan}>{school ? Math.round(state * 25) : frame > 23 && frame < 79 ? '1 / 42' : '0 / 42'}</InkText>
          <InkText x="450" y="687" size={25} center fill={muted} letterSpacing="3">{school ? 'ЗАПИСОК ОБ ОТСУТСТВИИ' : 'В ОФИСЕ'}</InkText>
        </Panel>
      );
      break;
    }
    case 'pizza': {
      const speed = interpolate(frame, [0, 70], [115, 0], bounds);
      content = (
        <Panel label="ТРЕКЕР ДОСТАВКИ" color={gold}>
          <g transform={`translate(${speed} 0)`}>
            <path d="M126 341H259M99 382H229M136 423H279" stroke={gold} strokeOpacity=".51" strokeWidth="6" strokeLinecap="round" />
            <g transform={`translate(251 ${252 + beat * 8}) rotate(-7 192 126)`}>
              <path d="M21 120L208 40L395 114L208 213Z" fill="#F0B16F" stroke="#513243" strokeWidth="5" />
              <path d="M21 120L208 213V250L21 159Z" fill="#CF7859" stroke="#513243" strokeWidth="5" />
              <path d="M208 213L395 114V150L208 250Z" fill="#99525B" stroke="#513243" strokeWidth="5" />
              <path d="M103 126Q201 69 308 120L214 182Z" fill="#FBE4AF" stroke="#B86263" strokeWidth="4" />
              <circle cx="193" cy="124" r="11" fill="#DD5369" /><circle cx="242" cy="126" r="12" fill="#DD5369" /><circle cx="215" cy="153" r="10" fill="#DD5369" />
            </g>
          </g>
          <Pad x={573} y={411} scale={.92} />
          <InkText x="450" y="618" center size={59}>КУРЬЕР В ИГРЕ</InkText>
          <InkText x="450" y="673" center size={29} fill={muted}>ДОСТАВКА ПРИОСТАНОВЛЕНА</InkText>
        </Panel>
      );
      break;
    }
    case 'shelves':
      content = (
        <Panel label="ЗАПАСЫ РАЙОНА" color={red}>
          <rect x="126" y="221" width="648" height="333" rx="20" fill="#30243D" stroke="#6C5479" strokeWidth="3" />
          {[0, 1].map((row) => (
            <g key={row} transform={`translate(0 ${142 * row})`}>
              <rect x="149" y="245" width="603" height="122" fill="#191427" rx="8" />
              {[0, 1, 2, 3, 4, 5].map((i) => (
                <g key={i} transform={`translate(${167 + i * 96} 0)`} opacity={.65 - state * .2}>
                  {row ? <path d="M12 295h47l-7 43H20Z" fill="none" stroke="#906983" strokeWidth="3" strokeDasharray="5 5" />
                    : <rect x="21" y="271" width="38" height="68" rx="9" fill="none" stroke="#906983" strokeWidth="3" strokeDasharray="5 5" />}
                  <path d="M4 351H76" stroke="#8C6792" strokeWidth="5" strokeLinecap="round" />
                </g>
              ))}
              <rect x="149" y="356" width="603" height="17" fill="#574262" />
              <rect x="642" y="344" width="95" height="34" rx="5" fill="#F3D7D4" stroke="#39283B" strokeWidth="2" />
              <InkText x="689" y="367" size={18} center fill="#471D39">0 ШТ</InkText>
            </g>
          ))}
          <InkText x="450" y="624" size={91} center fill={red}>0 ШТ</InkText>
          <InkText x="450" y="681" size={25} center fill={muted} letterSpacing="2.5">ЭНЕРГЕТИКИ / ЛАПША</InkText>
        </Panel>
      );
      break;
    case 'relationship': {
      const percent = Math.round(interpolate(state, [0, 1], variant > 0 ? [0, 11] : [100, 0]));
      content = (
        <Panel label="ФАН-ГИПОТЕЗА • ОТНОШЕНИЯ" color={pink}>
          <circle cx="265" cy="309" r="68" fill="#672D54" stroke={pink} strokeWidth="3" />
          <circle cx="635" cy="309" r="68" fill="#174351" stroke={cyan} strokeWidth="3" />
          <InkText x="265" y="335" size={74} center>Л</InkText>
          <InkText x="635" y="335" size={74} center>Д</InkText>
          <path d="M450 330L410 292C376 257 423 224 450 259C477 224 524 257 490 292Z" fill="#FD5D95" opacity={.5 + percent / 200} />
          <path d="M456 260L436 286L459 289L445 320" stroke="#28182C" strokeWidth="8" fill="none" />
          <InkText x="265" y="414" size={29} center fill={pink}>ЛУСИЯ</InkText>
          <InkText x="635" y="414" size={29} center fill={cyan}>ДЖЕЙСОН</InkText>
          <rect x="152" y="454" width="596" height="40" rx="20" fill="#3D2A48" />
          <rect x="152" y="454" width={596 * percent / 100} height="40" rx="20" fill={`url(#${charge})`} />
          <InkText x="450" y="609" center size={87} fill={percent < 25 ? red : white}>{percent}%</InkText>
          <InkText x="450" y="666" center size={27} fill={muted}>{variant > 0 ? 'СООБЩЕНИЕ ДОСТАВЛЕНО' : `${Math.min(3, 1 + Math.floor(state * 3))} СООБЩЕНИЯ БЕЗ ОТВЕТА`}</InkText>
        </Panel>
      );
      break;
    }
    case 'keys':
      content = variant > 0 ? (
        <Panel label="ФАН-ГИПОТЕЗА • ИНВЕНТАРЬ" color={red}>
          {['МАШИНА', 'УБЕЖИЩЕ', 'ПЁС'].map((label, i) => {
            const lost = frame >= 12 + i * 13;
            return (
              <g key={label} transform={`translate(${127 + i * 218} 258)`} opacity={lost ? .43 : 1}>
                <rect width="210" height="208" rx="24" fill="#302542" stroke={lost ? red : cyan} strokeWidth="3" />
                <g transform="translate(48 54)" fill="none" stroke={gold} strokeWidth="7" strokeLinecap="round" strokeLinejoin="round">
                  {i === 0 ? <path d="M1 83V56L20 22H92L112 56V83M1 58H112M20 82H92M19 67H31M83 67H95" />
                    : i === 1 ? <path d="M1 48L55 2L112 48M16 41V94H96V41M47 93V64H66V93" />
                    : <><path d="M20 79Q18 61 42 46Q55 35 72 46Q95 60 95 79Q88 103 58 89Q27 103 20 79Z" /><path d="M15 35h1m25-17h1m29 0h1m24 17h1" strokeWidth="14" /></>}
                </g>
                <InkText x="105" y="179" size={26} center>{label}</InkText>
                {lost && <path d="M39 47L174 152M174 47L39 152" stroke={red} strokeWidth="9" strokeLinecap="round" />}
              </g>
            );
          })}
          <InkText x="450" y="594" size={70} center fill={red}>{Math.min(3, Math.max(0, Math.floor((frame + 1) / 13)))} ПОТЕРИ</InkText>
          <InkText x="450" y="667" size={33} center fill={gold}>ХОДЬБА РАЗБЛОКИРОВАНА</InkText>
        </Panel>
      ) : (
        <Panel label="ФАН-ГИПОТЕЗА • ИНВЕНТАРЬ" color={red}>
          <g transform={`translate(450 351) rotate(${beat * 12 - 18})`}>
            <circle cx="-99" cy="-15" r="83" fill="none" stroke={gold} strokeWidth="28" />
            <circle cx="-99" cy="-15" r="83" fill="none" stroke="#FFE1AA" strokeWidth="5" opacity=".7" />
            <path d="M-53-40H185V10H152V43H112V15H76V45H38V15H-53Z" fill={gold} stroke="#663F4B" strokeWidth="4" />
            <path d="M-40-22H169" stroke="#FFF0BF" strokeWidth="5" strokeLinecap="round" />
          </g>
          <g transform={`translate(0 ${Math.max(0, 1 - flap(18)) * 66})`} opacity={Math.min(1, flap(18) * 2)}>
            <rect x="130" y="473" width="640" height="153" rx="21" fill="#481F36" stroke={red} strokeWidth="3" />
            <InkText x="450" y="543" center size={54}>ДОСТУП ОТОЗВАН</InkText>
            <InkText x="450" y="591" center size={27} fill="#FFB0B3">МАШИНА / УБЕЖИЩЕ</InkText>
          </g>
        </Panel>
      );
      break;
    case 'dog':
      content = (
        <Panel label="ФАН-ГИПОТЕЗА • НАПАРНИК" color={gold}>
          <g transform={`translate(${interpolate(frame, [0, 60], [404, 550], bounds)} ${384 + beat * 8}) rotate(${beat * 4}) scale(.92)`} stroke="#221524" strokeWidth="5">
            <path d="M-95-78Q-176-145-188-31Q-205 38-132 39L-69-24M95-78Q176-145 188-31Q205 38 132 39L69-24" fill="#704557" />
            <path d="M-147 1Q-158-126 0-132Q158-126 147 1Q138 121 0 129Q-138 121-147 1Z" fill="#C87D64" />
            <path d="M-117 38Q-106-18 0 31Q106-18 117 38Q112 110 0 117Q-112 110-117 38Z" fill="#FFE0AB" />
            <path d="M-27 30Q0 13 27 30Q21 58 0 62Q-21 58-27 30Z" fill="#3A2546" />
            <path d="M0 62Q-22 84-42 73M0 62Q22 84 42 73" fill="none" stroke="#3A2546" strokeWidth="5" strokeLinecap="round" />
            <path d="M-74 106Q0 133 74 106V137Q0 166-74 137Z" fill={cyan} />
            <circle cy="143" r="16" fill={gold} />
            <ellipse cx="-62" cy="-18" rx="16" ry="21" fill={white} /><ellipse cx="62" cy="-18" rx="16" ry="21" fill={white} />
            <ellipse cx="-56" cy="-14" rx="8" ry="13" fill={ink} stroke="none" /><ellipse cx="68" cy="-14" rx="8" ry="13" fill={ink} stroke="none" />
          </g>
          <path d={`M${548 + 107 * state} 512Q716 510 764 281`} stroke={pink} strokeWidth="5" fill="none" />
          <g transform={`translate(${157 - state * 44} 530)`}>
            <path d="M0 0H142L126 58H16Z" fill="#4E385B" stroke="#9C7898" strokeWidth="4" />
            <ellipse cx="71" cy="3" rx="71" ry="15" fill="#211831" stroke="#9C7898" strokeWidth="4" />
            <path d="M50 39q13-18 24 0q-12 14-24 0" fill={cyan} />
          </g>
          <InkText x="450" y="625" center size={57}>ПЁС УШЁЛ С НЕЙ</InkText>
          <InkText x="450" y="679" center size={26} fill={muted}>ВОЗРАЖЕНИЙ НЕТ</InkText>
        </Panel>
      );
      break;
    case 'sales': {
      const sum = grouped(interpolate(frame, [2, Math.round(fps * 2.2)], [0, 1_000_000_000], bounds));
      content = (
        <Panel label="ФАН-ПРОГНОЗ • ПЕРВЫЕ СУТКИ" color={green}>
          <InkText x="450" y="291" size={sum.length > 10 ? 68 : 91} center fill={green}>${sum}</InkText>
          <path d="M146 617H758M146 549H758M146 481H758M146 413H758M146 345H758" stroke="#4C395D" strokeWidth="2" strokeDasharray="6 9" />
          {[64, 98, 111, 151, 183, 217, 250, 277].map((target, i) => {
            const bar = target * Math.min(1, Math.max(0, flap(6 + i * 6)));
            return <rect key={i} x={172 + 74 * i} y={617 - bar} width="48" height={bar} rx="9" fill={i < 6 ? `url(#${charge})` : green} opacity={.42 + .08 * i} />;
          })}
          <path d="M146 617H758" stroke={green} strokeWidth="3" opacity=".74" />
          <InkText x="148" y="657" size={23} fill={muted}>00:00</InkText>
          <InkText x="757" y="657" size={23} fill={muted} textAnchor="end">24:00</InkText>
          <InkText x="450" y="697" size={23} center fill={green} letterSpacing="3">УСЛОВНЫЕ ЦИФРЫ</InkText>
        </Panel>
      );
      break;
    }
    case 'chat': {
      const lines = variant % 2
        ? ['КТО СНЯЛ АЛЛИГАТОРА?', 'БОСС • ПЕРЕСЛАНО', 'ПОДОЖДИ. ЭТО ЖЕ Я']
        : ['ТЫ НА РАБОТЕ?', 'У МЕНЯ ТУТ АЛЛИГАТОР', 'У МЕНЯ ТОЖЕ'];
      content = (
        <Panel label="ГРУППОВОЙ ЧАТ" color={cyan}>
          {lines.map((line, i) => {
            const fromRight = i === 1;
            const arrival = flap(i * 14 + 2);
            const x = fromRight ? 226 : 121;
            const width = i === 1 ? 548 : 524;
            return (
              <g key={line} transform={`translate(${(1 - Math.max(0, arrival)) * (fromRight ? 170 : -170)} 0)`} opacity={Math.min(1, Math.max(0, arrival) * 2)}>
                <rect x={x} y={235 + 145 * i} width={width} height="116" rx="25" fill={fromRight ? '#244657' : '#38284F'} stroke={fromRight ? cyan : '#9D75AF'} strokeWidth="2" />
                <InkText x={x + 30} y={306 + 145 * i} size={36} fill={fromRight ? cyan : white}>{line}</InkText>
                <path d={fromRight ? 'M739 329l8 7 14-17' : ''} transform={`translate(0 ${145 * i})`} fill="none" stroke={cyan} strokeWidth="3" />
              </g>
            );
          })}
        </Panel>
      );
      break;
    }
    case 'scanner': {
      const print = interpolate(frame, [13, 62], [0, 195], bounds);
      const packageX = interpolate(frame, [0, 75], [-184, 587], bounds);
      content = (
        <Panel label="КАССА № 06" color={red}>
          <g>
            <path d="M181 395L456 345L716 393L450 451Z" fill="#65516E" stroke="#141122" strokeWidth="5" />
            <path d="M181 395V499L450 560V451Z" fill="#3F3151" stroke="#141122" strokeWidth="5" />
            <path d="M450 451L716 393V494L450 560Z" fill="#27253F" stroke="#141122" strokeWidth="5" />
            <path d="M350 405L458 381L581 403L469 427Z" fill="#EC5C65" opacity={.58 + Math.abs(beat) * .41} />
            <path d="M384 399L502 379M391 406L528 383M404 412L546 386" stroke="#FFD7CD" strokeWidth="3" opacity=".87" />
          </g>
          {variant > 0 ? (
            <g>
              <path d="M465 440L594 412L624 420L492 451Z" fill="#110E1A" />
              {print > 0 && (
                <g>
                  <path d={`M471 439L613 412L${613 - print * .33} ${412 + print}L${471 - print * .33} ${442 + print}Z`} fill="#FBF2DD" stroke="#5C455A" strokeWidth="3" />
                  {Array.from({length: 6}, (_, i) => print > (i + 1) * 20 && <path key={i} d={`M${465 - i * 6} ${456 + i * 20}l${i % 2 ? 93 : 124} -26`} stroke="#746379" strokeWidth="4" opacity=".72" />)}
                </g>
              )}
            </g>
          ) : (
            <g opacity={interpolate(frame, [0, 10, 68, 82], [0, 1, 1, 0], bounds)}>
              <Carton x={packageX} y={277 - Math.sin(state * Math.PI) * 17} rotate={-12 + state * 46} />
              <path d="M444 280L485 419L548 391L465 273Z" fill="#FF3B59" opacity={.28 + .28 * Math.abs(beat)} />
            </g>
          )}
          <PulsePill x={263} y={231} width={378} color={variant > 0 ? green : red} text={variant > 0 ? 'ОПЛАТА ПРИНЯТА' : 'ОЖИДАНИЕ ОПЛАТЫ'} />
          <InkText x="450" y="652" center size={57}>{variant > 0 ? 'ЧЕК НА ХВОСТ' : 'СЛЕДУЮЩИЙ!'}</InkText>
        </Panel>
      );
      break;
    }
    case 'poll':
      content = (
        <Panel label={variant > 0 ? 'СОВЕЩАНИЕ • ПОВЕСТКА' : 'ОПРОС • ДЕНЬ РЕЛИЗА'} color={pink}>
          <InkText x="450" y="299" center size={61}>{variant > 0 ? 'КТО ЗАБРАЛ' : 'ВЫЙДЕШЬ'}</InkText>
          <InkText x="450" y="366" center size={61}>{variant > 0 ? 'МАШИНУ?' : 'НА РАБОТУ?'}</InkText>
          {(variant > 0 ? [['ЛУСИЯ', cyan], ['НАЧАЛЬНИК', pink]] : [['ДА', cyan], ['МНЕ УЖЕ ЗВОНЯТ', pink]]).map(([label, color], i) => (
            <g key={label}>
              <rect x="145" y={423 + i * 111} width="609" height="83" rx="20" fill="#302541" stroke={color} strokeWidth="2" opacity=".85" />
              <rect x="145" y={423 + i * 111} width={609 * state * (i ? .88 : .22)} height="83" rx="20" fill={color} opacity=".21" />
              <InkText x="450" y={477 + i * 111} size={36} center fill={color}>{label}</InkText>
            </g>
          ))}
        </Panel>
      );
      break;
    case 'timer': {
      const seconds = Math.max(0, 3 - Math.floor(frame / fps));
      const visible = interpolate(frame, [0, .3 * fps, 3 * fps, 3.47 * fps], [.35, 1, 1, 0], bounds);
      content = (
        <g opacity={visible}>
          <rect x="104" y="304" width="692" height="260" rx="40" fill="#191227" fillOpacity=".94" stroke={`url(#${edge})`} strokeWidth="4" />
          <InkText x="450" y="384" center size={28} fill={pink} letterSpacing="6">ДО РЕЛИЗА</InkText>
          <InkText x="450" y="492" center size={111} style={{fontVariantNumeric: 'tabular-nums'}}>00:00:0{seconds}</InkText>
          {[0, 1, 2].map(i => <rect key={i} x={252 + 137 * i} y="523" width="124" height="9" rx="4" fill={i < seconds ? pink : '#43304B'} />)}
        </g>
      );
      break;
    }
  }

  return (
    <svg viewBox="0 0 900 880" role="presentation" style={{width: '100%', height: '100%', overflow: 'visible'}}>
      <defs>
        <linearGradient id={edge} x1="5%" x2="95%" y1="0%" y2="100%">
          <stop stopColor="#A855F7" /><stop offset=".53" stopColor="#EC527A" /><stop offset="1" stopColor="#F97316" />
        </linearGradient>
        <linearGradient id={base} x1="8%" x2="93%" y1="0%" y2="100%">
          <stop stopColor="#25213F" stopOpacity=".98" /><stop offset="1" stopColor="#161326" stopOpacity=".98" />
        </linearGradient>
        <linearGradient id={charge}>
          <stop stopColor={pink} /><stop offset=".58" stopColor="#AC76FF" /><stop offset="1" stopColor={cyan} />
        </linearGradient>
      </defs>
      <g transform={`translate(0 ${lift})`}>
        {content}
      </g>
    </svg>
  );
};
