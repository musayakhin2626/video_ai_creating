import React, {useId} from 'react';
import {interpolate} from 'remotion';

export type Setting = 'store' | 'night' | 'sunset' | 'day' | 'office' | 'room' | 'map';

const W = 1080;
const H = 1920;

const noise = (n: number) => {
  const value = Math.sin(n * 78.233 + 49.17) * 43758.5453;
  return value - Math.floor(value);
};

const palettes = {
  night: {sky: ['#121024', '#37224f', '#a12b73'], sun: '#FF2E93', haze: '#9c427b', city: '#191833', front: '#141226', window: '#00F0FF', water: '#25193a'},
  sunset: {sky: ['#2a164c', '#7928CA', '#FF2A85', '#FF8A00'], sun: '#ffd27a', haze: '#e06572', city: '#412448', front: '#21172a', window: '#ffc991', water: '#45233f'},
  day: {sky: ['#15406a', '#337d9e', '#aadbc9'], sun: '#fff0a6', haze: '#9ec7c1', city: '#294b63', front: '#172b44', window: '#86eee2', water: '#2c6175'},
} as const;

const Palm: React.FC<{x: number; y: number; size: number; flip?: boolean; color: string}> = ({x, y, size, flip, color}) => (
  <g transform={`translate(${x} ${y}) scale(${flip ? -size : size} ${size})`} fill={color}>
    <path d="M-23 7Q-18-129 21-266L31-266Q5-130 5 7Z"/>
    <path d="M27-252Q-37-329-127-265Q-72-291-15-263L-43-265Q-4-255 27-252Z"/>
    <path d="M27-257Q-16-339-98-324Q-49-321-13-286L-36-298Q-9-268 27-257Z"/>
    <path d="M26-259Q25-355 108-363Q68-345 44-298L67-312Q49-276 26-259Z"/>
    <path d="M27-258Q89-328 164-290Q104-297 66-274L99-282Q68-257 27-258Z"/>
    <path d="M23-253Q120-283 142-211Q111-244 74-248L94-236Q58-238 23-253Z"/>
    <path d="M22-257Q-59-258-71-193Q-45-226-14-239L-29-217Q-2-230 22-257Z"/>
    <path d="M-19-49l25 7m-22-39l24 7m-20-41l23 8m-15-42l22 9m-13-42l20 9" fill="none" stroke="#b4738a" strokeOpacity=".22" strokeWidth="3"/>
  </g>
);

const Cityscape: React.FC<{setting: 'night' | 'sunset' | 'day'; phase: number; id: string}> = ({setting, phase, id}) => {
  const p = palettes[setting];
  const drift = phase * 39;
  return (
    <>
      <defs>
        <linearGradient id={`${id}-sky`} x2="0" y2="1">
          {p.sky.map((color, i) => <stop key={color} offset={i / (p.sky.length - 1)} stopColor={color}/>)}
        </linearGradient>
        <radialGradient id={`${id}-horizon`} cx=".68" cy=".71" r=".59">
          <stop stopColor={p.sun} stopOpacity=".35"/>
          <stop offset="1" stopColor={p.sun} stopOpacity="0"/>
        </radialGradient>
        <linearGradient id={`${id}-water`} x2="0" y2="1">
          <stop stopColor={p.water}/>
          <stop offset="1" stopColor="#151326"/>
        </linearGradient>
      </defs>
      <rect width={W} height="1270" fill={`url(#${id}-sky)`}/>
      <rect width={W} height="1180" fill={`url(#${id}-horizon)`}/>
      {setting === 'night' ? (
        <g fill="#ffe9f3">
          {Array.from({length: 46}, (_, i) => (
            <circle key={i} cx={noise(i * 6 + 8) * W} cy={185 + noise(i * 8 + 42) * 700} r={1.2 + noise(i + 10) * 1.8} opacity={.18 + noise(i * 4) * .52}/>
          ))}
          <circle cx={815 - drift * .08} cy="460" r="55" fill="#ffbbd7" fillOpacity=".76"/>
          <circle cx={838 - drift * .08} cy="442" r="48" fill="#39204d"/>
        </g>
      ) : (
        <circle cx={735 - drift * .13} cy={setting === 'day' ? 470 : 750} r={setting === 'day' ? 70 : 169} fill={p.sun} fillOpacity={setting === 'day' ? .69 : .83}/>
      )}
      <g opacity={setting === 'day' ? .35 : .26} fill={p.haze} transform={`translate(${-drift * .2} 0)`}>
        <path d="M-20 531Q86 508 174 516Q217 467 302 514Q460 507 513 531Z"/>
        <path d="M497 727Q560 700 663 709Q729 664 829 704Q942 694 1070 729Z"/>
        <path d="M-31 745Q33 726 178 722Q261 682 332 725Q411 726 465 744Z"/>
      </g>
      <g transform={`translate(${-drift * .28} 0)`}>
        {Array.from({length: 22}, (_, i) => {
          const x = i * 57 - 40;
          const y = 1023 - (52 + noise(i + 9) * 188);
          const width = 29 + noise(i * 4 + 5) * 37;
          return <path key={i} d={`M${x} 1045V${y}h${width * .32}v-13h${width * .5}v13H${x + width}v${1045-y}Z`} fill={p.city} fillOpacity=".68"/>;
        })}
      </g>
      <g transform={`translate(${-drift * .55} 0)`}>
        {Array.from({length: 15}, (_, i) => {
          const x = i * 89 - 86;
          const width = 53 + noise(i * 7 + 5) * 29;
          const y = 1037 - (114 + noise(i + 25) * 286);
          return (
            <g key={i}>
              <path fill={p.front} d={`M${x} 1061V${y+24}h7v-16h10v-8h${width-34}v8h10v16h7v${1061-y-24}Z`}/>
              <path d={`M${x+11} ${y+27}h${width-22}`} stroke={p.window} strokeOpacity=".47" strokeWidth="3"/>
              {Array.from({length: Math.min(10, Math.floor((1016-y)/26))}, (_, row) => (
                <g key={row} fill={p.window} opacity={.2 + noise(i + row) * .45}>
                  <rect x={x+12} y={y+41+row*26} width="6" height="12" rx="1"/>
                  <rect x={x+width/2-3} y={y+41+row*26} width="6" height="12" rx="1"/>
                  <rect x={x+width-17} y={y+41+row*26} width="6" height="12" rx="1" opacity={noise(i*3+row) > .38 ? 1 : .18}/>
                </g>
              ))}
              <path d={`M${x+width/2} ${y}v-18`} stroke={p.front} strokeWidth="3" opacity={i % 4 === 0 ? 1 : 0}/>
            </g>
          );
        })}
      </g>
      <rect y="1045" width={W} height="338" fill={`url(#${id}-water)`}/>
      <path d="M0 1046H1080" stroke={p.window} strokeWidth="3" opacity=".5"/>
      <g opacity=".18">
        {Array.from({length: 36}, (_, i) => {
          const x = noise(i * 4 + 4) * W - 37 + Math.cos(phase * 6 + i) * 20;
          const y = 1058 + noise(i * 8 + 24) * 190;
          return <path key={i} d={`M${x} ${y}h${19 + noise(i + 3)*108}`} stroke={i % 3 ? p.window : p.sun} strokeWidth={1 + 3 * noise(i)}/>;
        })}
      </g>
      <path d="M0 1298L1080 1205V1920H0Z" fill={p.front}/>
      <path d="M0 1300L1080 1208" stroke={p.haze} strokeWidth="9" opacity=".62"/>
      <path d="M0 1363L1080 1242m-1080 192l1080-153m-1080 235l1080-191" stroke={p.window} strokeWidth="3" opacity=".15"/>
      <Palm x={96 - drift} y={1335} size={1.36} color={p.front}/>
      <Palm x={983 - drift * .85} y={1244} size={1.12} flip color={p.front}/>
      <Palm x={862 - drift * .67} y={1223} size={.65} flip color={p.front}/>
    </>
  );
};

const Cabinet: React.FC<{x: number; y: number; scale: number; seed: number; dir: number}> = ({x, y, scale, seed, dir}) => (
  <g transform={`translate(${x} ${y}) scale(${dir * scale} ${scale})`}>
    <path d="M0 0h260l60 81v436l-60 54H0Z" fill="#1f1a36" stroke="#131020" strokeWidth="5"/>
    <path d="M260 0l60 81v436l-60 54Z" fill="#362346"/>
    <path d="M4 31h248v485H4Z" fill="#151527"/>
    <path d="M4 10h246" fill="none" stroke="#ff2e93" strokeWidth="6" opacity=".77"/>
    {[96, 208, 322, 434].map((row, i) => (
      <g key={row}>
        <path d={`M0 ${row}h258v16H0z`} fill={i % 2 ? '#3e3354' : '#563351'}/>
        <path d={`M8 ${row+4}h242`} stroke="#b07999" strokeWidth="2" opacity=".64"/>
        {Array.from({length: 8}, (_, column) => {
          const t = noise(seed + i * 14 + column);
          return t > .22 ? <rect key={column} x={13 + column * 30} y={row - 24 - t * 24} width={14 + t*9} height={24 + t*24} rx={t > .62 ? 6 : 2} fill={t > .77 ? '#685078' : (t > .51 ? '#5a746e' : '#784666')}/> : null;
        })}
      </g>
    ))}
    <path d="M0 517h260v26H0Z" fill="#2d2243"/>
  </g>
);

const Store: React.FC<{phase: number; id: string}> = ({phase, id}) => (
  <>
    <defs>
      <linearGradient id={`${id}-store-wall`} x2="0" y2="1">
        <stop stopColor="#151227"/><stop offset=".63" stopColor="#39223f"/><stop offset="1" stopColor="#151426"/>
      </linearGradient>
      <linearGradient id={`${id}-store-floor`} x2="0" y2="1">
        <stop stopColor="#35213e"/><stop offset="1" stopColor="#161326"/>
      </linearGradient>
      <radialGradient id={`${id}-store-glow`} cx=".51" cy=".48" r=".52">
        <stop stopColor="#ed468c" stopOpacity=".35"/><stop offset="1" stopColor="#ed468c" stopOpacity="0"/>
      </radialGradient>
    </defs>
    <rect width={W} height={H} fill={`url(#${id}-store-wall)`}/>
    <rect y="1118" width={W} height="802" fill={`url(#${id}-store-floor)`}/>
    <path d="M0 500L540 738L1080 500V0H0Z" fill="#18142a"/>
    <path d="M0 499L540 737L1080 499" fill="none" stroke="#b84e7b" strokeWidth="6" opacity=".66"/>
    <path d="M0 485L540 724L1080 485" fill="none" stroke="#f379a6" strokeOpacity=".49" strokeWidth="2"/>
    {[1, 2, 3, 4].map((step) => (
      <g key={step}>
        <path d={`M${490-step*92} ${715-step*78}H${590+step*92}`} stroke="#774568" strokeWidth="14"/>
        <path d={`M${490-step*92} ${715-step*78}H${590+step*92}`} stroke="#ff91c1" strokeOpacity={.44 + Math.sin(phase * 6 + step) * .11} strokeWidth="4"/>
      </g>
    ))}
    <path d="M0 1120h1080" stroke="#cc629e" strokeOpacity=".35" strokeWidth="4"/>
    <g stroke="#8b598b" strokeOpacity=".32" strokeWidth="3" fill="none">
      {[-5, -4, -3, -2, -1, 0, 1, 2, 3, 4, 5].map((step) => <path key={step} d={`M${540+step*50} 1119L${540+step*245} 1920`}/>)}
      {[1155, 1207, 1278, 1377, 1509, 1677, 1886].map((y) => <path key={y} d={`M0 ${y}h1080`}/>)}
    </g>
    <rect x="342" y="742" width="394" height="411" rx="14" fill="#17182e" stroke="#211529" strokeWidth="12"/>
    <path d="M354 760h370v385H354Z" fill="#273753" stroke="#745d7d" strokeWidth="4"/>
    <path d="M366 939l185-179h98L369 1031Z" fill="#ea6ca4" opacity=".14"/>
    <path d="M541 763v377M354 1069h370" stroke="#a67399" strokeWidth="3" opacity=".64"/>
    <path d="M514 991v56m56-56v56" stroke="#dbc0cf" strokeWidth="6"/>
    <Cabinet x={-21 - phase * 20} y={763} scale={1.14} seed={10} dir={1}/>
    <Cabinet x={1101 - phase * 20} y={763} scale={1.14} seed={100} dir={-1}/>
    <rect width={W} height={H} fill={`url(#${id}-store-glow)`}/>
  </>
);

const Office: React.FC<{room: boolean; id: string; phase: number}> = ({room, id, phase}) => (
  <>
    <defs>
      <linearGradient id={`${id}-interior`} x2="0" y2="1">
        <stop stopColor="#19152b"/><stop offset=".72" stopColor={room ? '#342747' : '#304555'}/><stop offset="1" stopColor="#19172a"/>
      </linearGradient>
      <linearGradient id={`${id}-window`} x2="0" y2="1">
        <stop stopColor={room ? '#34366b' : '#3c647e'}/><stop offset="1" stopColor={room ? '#b84d79' : '#a2d6c2'}/>
      </linearGradient>
    </defs>
    <rect width={W} height={H} fill={`url(#${id}-interior)`}/>
    <path d="M0 371l540 183 540-183V0H0Z" fill="#191528"/>
    <path d="M0 379l540 184 540-184" fill="none" stroke="#876b98" strokeWidth="3" opacity=".57"/>
    <rect x="125" y="534" width="830" height="629" rx="36" fill="#16192e" stroke="#222238" strokeWidth="25"/>
    <rect x="143" y="552" width="794" height="590" rx="22" fill={`url(#${id}-window)`}/>
    <g fill={room ? '#362b51' : '#3a6271'}>
      {Array.from({length: 12}, (_, i) => {
        const x = 149 + i * 65 - phase * 7;
        const top = 980 - noise(i * 4 + 9) * 185;
        return <rect key={i} x={x} y={top} width={33+noise(i)*30} height={1129-top}/>;
      })}
    </g>
    <path d="M143 552h265L143 905Zm192 590L799 552h97l-454 590Z" fill="#ededf7" opacity=".15"/>
    <path d="M410 553v590m260-590v590M145 910H938" stroke="#222038" strokeWidth="11"/>
    <path d="M0 1160h1080v760H0Z" fill="#232139"/>
    <path d="M0 1177h1080" stroke={room ? '#a3438e' : '#61a5ae'} strokeWidth="5" opacity=".66"/>
    <g stroke={room ? '#755673' : '#61728d'} strokeOpacity=".45" strokeWidth="3">
      {[-3, -2, -1, 0, 1, 2, 3].map((step) => <path key={step} d={`M${540+step*83} 1180L${540+step*202} 1920`}/>)}
    </g>
    {room ? (
      <>
        <path d="M47 1230h345q85 0 85 87v139H17v-196Z" fill="#392543" stroke="#171422" strokeWidth="6"/>
        <path d="M15 1318h455M67 1242v74m172-74v74" stroke="#84597b" strokeWidth="3"/>
        <path d="M704 1279h344l-38 43H662Z" fill="#72466b" stroke="#241a33" strokeWidth="5"/>
        <path d="M690 1322v201m303-201v201" stroke="#20192c" strokeWidth="16"/>
        <path d="M762 1054h208v173H762Z" fill="#151427" stroke="#654964" strokeWidth="6"/>
        <rect x="775" y="1067" width="181" height="145" rx="6" fill="#304366"/>
        <path d="M775 1200l99-133h38l-103 145h-34Z" fill="#797b9a" opacity=".32"/>
        <path d="M854 1231v35m-36 0h72" stroke="#171529" strokeWidth="10"/>
      </>
    ) : (
      <>
        {[173, 474, 775].map((x, i) => (
          <g key={x} transform={`translate(${x} ${i === 1 ? 38 : 0})`}>
            <path d="M-31 1233h252l27 60H-58Z" fill="#62717d" stroke="#262639" strokeWidth="6"/>
            <path d="M-26 1295v170m235-170v170" stroke="#201e34" strokeWidth="11"/>
            <rect x="-8" y="1110" width="163" height="104" rx="10" fill="#1c1c2e" stroke="#76959c" strokeWidth="5"/>
            <path d="M72 1214v25m-25 0h50" stroke="#302a40" strokeWidth="8"/>
            <path d="M71 1375h113v-112q0-19-22-19h-66q-25 0-25 19Z" fill="#3a465f" stroke="#25263c" strokeWidth="7"/>
            <path d="M124 1378v49m-44 0h88" stroke="#222037" strokeWidth="9"/>
          </g>
        ))}
      </>
    )}
  </>
);

const MapView: React.FC<{phase: number; id: string}> = ({phase, id}) => (
  <>
    <defs>
      <pattern id={`${id}-map-grid`} width="56" height="56" patternUnits="userSpaceOnUse">
        <path d="M56 0H0V56" fill="none" stroke="#3d4b65" strokeWidth="2"/>
      </pattern>
    </defs>
    <rect width={W} height={H} fill="#15172c"/>
    <rect width={W} height={H} fill={`url(#${id}-map-grid)`} opacity=".66"/>
    <g transform={`translate(${-phase * 24} ${phase * 12}) rotate(-24 540 960)`}>
      <path d="M714-100H1260V2200H773Q691 2056 742 1882T734 1584Q686 1462 742 1271T743 868Q651 721 719 577T714-100Z" fill="#243753" stroke="#4f8e9d" strokeWidth="5"/>
      <g fill="#233047" stroke="#283d55" strokeWidth="3">
        {Array.from({length: 12}, (_, row) => (
          <g key={row}>
            {Array.from({length: 7}, (_, col) => <rect x={-159 + col * 122} y={185 + row * 141} width={90 + 13*noise(col*3+row)} height="107" rx="10" key={col}/>)}
          </g>
        ))}
      </g>
      <g stroke="#60738b" strokeWidth="9" opacity=".49">
        {[46, 267, 506].map((x) => <path key={x} d={`M${x} -300V2300`}/>)}
        {[307, 584, 861, 1138, 1415, 1692].map((y) => <path key={y} d={`M-400 ${y}H${y === 861 || y === 1415 ? 1600 : 713}`}/>)}
      </g>
      <path d="M46 1448V1138h221V861h239V584h180" fill="none" stroke="#FF2E93" strokeOpacity=".68" strokeWidth="7" strokeDasharray="14 12" strokeDashoffset={-phase * 64}/>
      <circle cx="46" cy="1448" r="13" fill="#FF2E93"/>
      <circle cx="686" cy="584" r="13" fill="#00f0ff"/>
    </g>
  </>
);

export const ViceCityBg: React.FC<{setting: Setting; frame: number; fps: number}> = ({setting, frame, fps}) => {
  const id = useId();
  const phase = interpolate(frame, [0, fps * 3.5], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return (
    <svg viewBox={`0 0 ${W} ${H}`} width={W} height={H} aria-hidden="true" style={{position: 'absolute', inset: 0, display: 'block'}}>
      <defs>
        <radialGradient id={`${id}-vignette`} cx=".5" cy=".47" r=".72">
          <stop offset=".42" stopColor="#101020" stopOpacity="0"/>
          <stop offset="1" stopColor="#0a0818" stopOpacity=".8"/>
        </radialGradient>
        <linearGradient id={`${id}-edge`} x2="0" y2="1">
          <stop stopColor="#100d22" stopOpacity=".64"/>
          <stop offset=".26" stopColor="#100d22" stopOpacity="0"/>
          <stop offset=".64" stopColor="#100d22" stopOpacity="0"/>
          <stop offset="1" stopColor="#100d22" stopOpacity=".86"/>
        </linearGradient>
        <pattern id={`${id}-grain`} width="97" height="111" patternUnits="userSpaceOnUse">
          <path d="M3 7h3m76 1h2M55 23h2m-42 7h3m74 11h3M3 53h4m43 10h4m30 12h3m-65 10h1m39 9h3m-32 8h2m59 8h2" fill="none" stroke="white" strokeWidth="1" opacity=".16"/>
        </pattern>
      </defs>
      {setting === 'store' && <Store phase={phase} id={id}/>}
      {(setting === 'night' || setting === 'day' || setting === 'sunset') && <Cityscape setting={setting} phase={phase} id={id}/>}
      {(setting === 'office' || setting === 'room') && <Office room={setting === 'room'} phase={phase} id={id}/>}
      {setting === 'map' && <MapView phase={phase} id={id}/>}
      <rect width={W} height={H} fill={`url(#${id}-grain)`}/>
      <rect width={W} height={H} fill={`url(#${id}-edge)`}/>
      <rect width={W} height={H} fill={`url(#${id}-vignette)`}/>
    </svg>
  );
};
