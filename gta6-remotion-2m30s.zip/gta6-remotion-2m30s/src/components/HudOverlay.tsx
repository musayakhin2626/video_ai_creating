import {interpolate} from "remotion";
import {TIMELINE} from "../timeline";

type HudProps = {
  frame: number;
  chapter: string;
  wanted: number;
};

export const HudOverlay = ({frame, chapter, wanted}: HudProps) => (
  <div className="hud">
    <div className="progress">
      {TIMELINE.map(({startFrame, durationInFrames}) => (
        <div className="progress-track" key={startFrame}>
          <div
            className="progress-fill"
            style={{
              width: `${interpolate(frame, [startFrame, startFrame + durationInFrames - 1], [0, 100], {
                extrapolateLeft: "clamp",
                extrapolateRight: "clamp",
              })}%`,
            }}
          />
        </div>
      ))}
    </div>
    <div className="hud-row">
      <div className="chapter">{chapter}</div>
      <div className="wanted" aria-label={`Звёзды розыска: ${wanted} из 5`}>
        {Array.from({length: 5}, (_, index) => (
          <span key={index} className={index < wanted ? "lit" : ""}>★</span>
        ))}
      </div>
    </div>
    <div className="fiction">ФАН-СЦЕНАРИЙ · СОБЫТИЯ И ЦИФРЫ ВЫМЫШЛЕНЫ</div>
  </div>
);
