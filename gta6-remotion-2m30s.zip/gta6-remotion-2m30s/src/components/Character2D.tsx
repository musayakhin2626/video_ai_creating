import React, {useId} from 'react';
import {interpolate, spring} from 'remotion';

type Mood = 'panic' | 'tired' | 'focused' | 'smug';
type CharacterProps = {
  frame: number;
  fps: number;
  mood?: Mood;
  close?: boolean;
  speaking?: boolean;
};

const ink = '#111111';
const faceEdge = 'M247 200C239 154 262 115 306 93C361 68 430 73 472 96C523 115 547 164 546 215L535 305C532 365 500 417 451 454C418 479 380 480 344 459C294 430 271 392 260 335Z';
const leftEye = 'M285 279Q316 249 359 278Q326 304 286 287Z';
const rightEye = 'M425 277Q464 251 504 272Q475 299 426 287Z';
const shoulderEdge = 'M293 448C261 452 224 474 187 493L121 517C77 536 57 577 48 639L21 823Q27 885 109 909L698 909Q765 884 777 820L750 635C741 571 721 540 666 514L599 492C555 473 530 447 505 447L461 487L398 523L334 482Z';
const padEdge = 'M291 707C309 690 332 692 350 703L442 703C462 692 491 689 508 715C528 748 556 815 538 838C526 855 510 850 486 829L454 798L335 798L305 834C279 859 254 847 254 827C255 797 271 732 291 707Z';

export const Character2D: React.FC<CharacterProps> = ({
  frame, fps, mood = 'panic', close = false, speaking = true,
}) => {
  const id = `player-${useId().replace(/[^\w-]/g, '')}`;
  const t = frame / fps;
  const blinkClock = ((t + 0.21) % 2.13) / 2.13;
  const blink = interpolate(blinkClock, [0, 0.03, 0.072, 1], [1, 0.03, 1, 1]);
  const awake = mood === 'tired' ? 0.74 : mood === 'smug' ? 0.71 : 1;
  const eyeOpen = blink * awake;
  const look = Math.sin(t * 5.8 + 0.2) * (mood === 'panic' ? 8 : 4);
  const breath = 2.4 * Math.sin(t * 5.4);
  const brow = mood === 'panic' ? -10 - Math.sin(t * 6) * 4 : mood === 'smug' ? 8 : 4;
  const speech = (0.26 + 0.74 * Math.abs(Math.sin(t * 18) * Math.cos(t * 5.5))) * Number(speaking);
  const open = mood === 'panic' ? 14 + speech * 24 : 3 + speech * 17;
  const rub = Math.sin(t * 11.2) * (mood === 'panic' ? 4.5 : 1.9);
  const mouth = mood === 'panic'
    ? `M359 390Q372 ${371 - open * 0.19} 397 377Q419 ${373 + open * 0.35} 426 392Q421 ${399 + open * 0.65} 399 ${401 + open * 0.61}Q374 ${404 + open * 0.5} 359 390Z`
    : `M353 388Q388 ${374 - open * 0.17} 435 382Q407 ${392 + open} 383 ${394 + open}Q364 ${392 + open * 0.7} 353 388Z`;
  const sclera = mood === 'tired' ? '#FFD2CD' : mood === 'panic' ? '#FFE6DA' : '#FFF2E3';

  return (
    <svg width="100%" height="100%" viewBox={close ? '245 171 302 253' : '0 0 800 910'}
      xmlns="http://www.w3.org/2000/svg" aria-label="Геймер в бирюзовой рубашке">
      <defs>
        <linearGradient id={`${id}-skin`} x1="0" x2="0.82" y1="0.15" y2="1" gradientUnits="objectBoundingBox">
          <stop stopColor="#FFC184"/><stop offset=".55" stopColor="#E99E73"/><stop offset="1" stopColor="#CA7657"/>
        </linearGradient>
        <linearGradient id={`${id}-lens`} x2="1" y2="1" gradientUnits="objectBoundingBox">
          <stop stopColor="#222B50"/><stop offset=".45" stopColor="#433559"/><stop offset="1" stopColor="#141925"/>
        </linearGradient>
        <linearGradient id={`${id}-shirt`} x2=".68" y2="1" gradientUnits="objectBoundingBox">
          <stop stopColor="#249F93"/><stop offset=".46" stopColor="#158F8B"/><stop offset="1" stopColor="#105758"/>
        </linearGradient>
        <linearGradient id={`${id}-pad`} x2="0" y2="1" gradientUnits="objectBoundingBox">
          <stop stopColor="#3D3B54"/><stop offset="1" stopColor="#19182B"/>
        </linearGradient>
        <pattern id={`${id}-flora`} width="126" height="121" patternUnits="userSpaceOnUse" patternTransform="rotate(-14)">
          <path d="M12 94C24 68 52 47 74 50Q40 56 32 87ZM24 105Q52 71 72 71Q64 94 37 107ZM67 29Q77 9 99 5Q88 28 67 29ZM108 116Q106 91 125 74Q126 100 108 116Z" fill="#75DDC1" opacity=".65"/>
          <path d="M13 95Q26 74 50 62M25 105Q45 85 60 82M67 29L88 13" stroke="#136459" strokeWidth="1.7" fill="none"/>
          <path d="M85 43C72 33 66 49 75 57C58 57 59 72 72 73C64 86 78 93 86 81C92 95 107 86 101 74C115 79 120 63 107 59C119 49 111 38 98 45C96 33 88 34 85 43Z" fill="#F3569E" stroke="#992D73" strokeWidth="1.7"/>
          <path d="M86 47L88 61L77 68L88 66L100 75M93 62L103 50" fill="none" stroke="#B12D76" strokeWidth="2.3"/>
          <circle cx="91" cy="63" r="5.5" fill="#FFD284"/><circle cx="88" cy="59" r="1.4" fill="#FDF3A4"/>
          <path d="M13 20q13-12 20 3Q23 36 13 20zM104 92q7-5 12 1q-5 6-12-1z" fill="#FF99B8" opacity=".65"/>
        </pattern>
        <clipPath id={`${id}-face`}><path d={faceEdge}/></clipPath>
        <clipPath id={`${id}-left`}><path d={leftEye}/></clipPath>
        <clipPath id={`${id}-right`}><path d={rightEye}/></clipPath>
        <clipPath id={`${id}-mouth`}><path d={mouth}/></clipPath>
      </defs>
      <g transform={`translate(${0.8 * Math.sin(t * 7)} ${breath})`} stroke={ink} strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round">
        <path d="M302 436Q305 485 292 511L394 571L504 502Q479 471 480 422Z" fill={`url(#${id}-skin)`}/>
        <path d="M303 448Q338 485 391 494Q451 498 483 461Q487 480 498 492L397 551L315 507Z" fill="#AC5763" opacity=".72" stroke="none"/>
        <path d={shoulderEdge} fill={`url(#${id}-shirt)`}/>
        <path d={shoulderEdge} fill={`url(#${id}-flora)`} opacity=".82"/>
        <path d="M140 531Q178 577 155 650L127 760L121 906H108Q34 897 21 824L47 648Q60 552 140 531ZM663 521Q617 561 641 659L686 791 690 909Q757 892 777 820L750 639Q735 559 663 521Z" fill="#063A4C" opacity=".46" stroke="none"/>
        <path d="M80 582Q130 530 200 517M579 498Q633 526 675 530M140 655l-13 104m520-104 27 101" fill="none" stroke="#76E7CA" opacity=".36" strokeWidth="5"/>
        <path d="M166 511Q148 538 149 579L155 640M635 508Q650 551 648 601L645 636M165 829l16 74m433-70-13 65" fill="none" opacity=".8"/>
        <path d="M301 442Q280 455 263 473L281 552L324 595L385 543Q342 514 301 442Z" fill="#1DB0A8"/>
        <path d="M493 442Q514 452 534 473L511 551L472 595L408 541Q461 510 493 442Z" fill="#1A9A9D"/>
        <path d="M269 479l21 65 32 37 46-40m153-61-19 63-30 36-44-39" fill="none" stroke="#9BEFD3" strokeWidth="2.1" opacity=".75"/>
        <path d="M384 544Q420 602 416 668L428 899" fill="none" stroke="#0A605F" strokeWidth="3"/>
        <circle cx="405" cy="613" r="4.5" fill="#E1C082"/>
        <circle cx="411" cy="674" r="4.5" fill="#E1C082"/>
        <path d="M298 504Q319 579 389 592Q451 601 496 506" fill="none" stroke="#342628" strokeWidth="8"/>
        <path d="M298 504Q319 579 389 592Q451 601 496 506" fill="none" stroke="#F9C46C" strokeWidth="4"/>
        <path d="M391 595l-8 18 11 8 11-12-9-14z" fill="#FFE18B" strokeWidth="2.4"/>
        <path d="M256 472Q250 514 280 555Q322 608 391 599Q471 605 519 545Q541 515 534 473" fill="none" strokeWidth="26"/>
        <path d="M256 472Q250 514 280 555Q322 608 391 599Q471 605 519 545Q541 515 534 473" fill="none" stroke="#464461" strokeWidth="17"/>
        <path d="M259 473Q255 511 283 548M528 478Q532 511 506 546" fill="none" stroke="#9C9BCF" strokeWidth="2.7"/>
        <g transform="rotate(-33 291 559)">
          <rect x="250" y="508" width="80" height="102" rx="30" fill="#201F35"/>
          <rect x="259" y="515" width="50" height="88" rx="23" fill="#414465"/>
          <path d="M278 534V586" stroke="#00F0FF" strokeWidth="5"/>
          <path d="M293 541v39" stroke="#7378A2" strokeWidth="3"/>
        </g>
        <g transform="rotate(31 496 559)">
          <rect x="460" y="507" width="74" height="104" rx="29" fill="#252444"/>
          <rect x="482" y="513" width="44" height="92" rx="20" fill="#525379"/>
          <path d="M504 532V585" stroke="#FF5BA8" strokeWidth="5"/>
        </g>

        <path d="M250 259Q228 239 213 259C190 300 220 354 266 345L269 304ZM531 249Q555 230 571 250C592 283 571 341 528 341L519 297Z" fill={`url(#${id}-skin)`}/>
        <path d="M232 269q24-9 27 23q-20-19-26 9q1 25 23 25m292-58q19-16 21 7q3 28-23 44" stroke="#A05259" fill="none"/>
        <path d={faceEdge} fill={`url(#${id}-skin)`}/>
        <g clipPath={`url(#${id}-face)`} stroke="none">
          <path d="M248 169Q268 238 284 279L275 321 298 385 338 440 382 467 367 483 275 449 229 358 223 214Z" fill="#B66A56"/>
          <path d="M477 86Q522 143 517 198L511 288 491 328 488 388 440 442 390 469 469 470 526 411 561 328 561 168Z" fill="#B96866" opacity=".75"/>
          <path d="M294 165Q340 149 409 157L463 175 453 199 320 209 280 231Z" fill="#FFD29E" opacity=".7"/>
          <path d="M298 311Q336 304 365 316L357 340 312 351 286 331ZM436 316Q472 306 494 292L497 317 466 339 432 338Z" fill="#FFA9A2" opacity=".55"/>
          <path d="M314 399Q337 414 375 417L423 416 456 400Q430 451 389 455Q347 447 314 399Z" fill="#75454E" opacity=".28"/>
          <path d="M335 397Q379 385 418 393L445 387 434 401 375 407Z" fill="#985247" opacity=".5"/>
          <path d="M380 281L362 341 374 369 396 363 405 343 389 322 392 279Z" fill="#FFCC8F"/>
          <path d="M396 300Q414 326 418 348Q419 360 402 367L383 367 401 349Z" fill="#AC6559" opacity=".7"/>
        </g>

        <path d="M243 262Q222 230 222 186Q211 153 240 127Q247 82 307 61Q361 40 422 54Q462 40 499 70Q538 69 556 120Q578 151 559 195Q562 240 539 263L524 291L518 220Q508 187 494 165Q451 173 415 158Q368 182 324 163Q312 188 280 206L264 272L252 255 248 294Z" fill="#202032"/>
        <path d="M244 157Q258 104 319 89Q360 78 412 91Q404 104 367 111Q429 96 481 117Q462 139 416 145Q369 163 316 147Q279 173 246 178Z" fill="#42324D" stroke="none"/>
        <path d="M244 192Q260 168 282 159Q268 182 254 220M264 139Q292 106 334 104M306 121Q339 100 371 104M408 122Q454 103 491 121M453 129Q481 117 509 131" fill="none" stroke="#6B4A62" strokeWidth="3.7"/>
        <path d="M528 171Q550 188 543 232L531 263Q533 214 512 188Z" fill="#352A40" stroke="none"/>
        <path d="M527 193q10 23 7 56m5-50 8 22" fill="none" stroke="#84566F" strokeWidth="2.5"/>
        <path d="M239 161Q245 120 290 89Q324 67 361 68M469 66Q513 77 541 117" fill="none" stroke="#F864AB" strokeWidth="4.5" opacity=".75"/>
        <path d="M252 249l-5-36 13-32m289 61 9-36-13-37" fill="none" stroke="#0F1424" strokeWidth="7"/>

        <g transform="rotate(-3 402 165)">
          <path d="M256 166L273 126M544 157l-16-32M362 145q28-12 66 0" fill="none" stroke="#262435" strokeWidth="12"/>
          <path d="M268 131Q311 119 362 132L379 144 365 174Q356 190 329 191L294 186Q276 183 270 164Z" fill={`url(#${id}-lens)`}/>
          <path d="M426 133Q483 118 529 129L527 159Q520 183 498 186L465 190Q438 190 429 174L415 147Z" fill={`url(#${id}-lens)`}/>
          <path d="M279 139Q322 128 354 139M433 143q36-15 84-9" fill="none" stroke="#FF7FBE" strokeWidth="2.4"/>
          <path d="M297 183l38-51 13 2-36 51m151 2 41-55 11 2-38 54" fill="#75DADA" opacity=".43" stroke="none"/>
          <path d="M380 146q18-6 36-1" fill="none" stroke="#FFF1B8" strokeWidth="2.6"/>
        </g>

        <g transform={`translate(0 ${mood === 'panic' ? -3 : 1})`} fill="#302136">
          <path transform={`rotate(${brow} 326 251)`} d="M280 261Q312 233 347 243L365 248 361 256Q320 249 282 269Z"/>
          <path transform={`rotate(${-brow - 3} 465 247)`} d="M423 248Q452 225 488 231L502 241 501 250Q464 237 426 256Z"/>
        </g>
        <g transform={`translate(0 ${280 * (1 - eyeOpen)}) scale(1 ${eyeOpen})`}>
          <path d={leftEye} fill={sclera}/><path d={rightEye} fill={sclera}/>
          <g clipPath={`url(#${id}-left)`}>
            <path d="M284 284l12-3 4-8m-4 8 9 6m45-19-8 7 4 4-9 8m-45-17 11-7m-4 23 1 4" stroke="#D96E85" strokeWidth="1.6" fill="none"/>
            <ellipse cx={327 + look} cy="279" rx="12" ry="15" fill="#866456"/>
            <ellipse cx={327 + look} cy="280" rx="5.2" ry="8.5" fill="#171628" stroke="none"/>
            <circle cx={323 + look} cy="275" r="3.4" fill="white" stroke="none"/>
          </g>
          <g clipPath={`url(#${id}-right)`}>
            <path d="M429 273l12 6 4-5m-4 5 2 8m61-14-10 1-4-8m4 8-9 9m5 2 4 5" stroke="#D96E85" strokeWidth="1.6" fill="none"/>
            <ellipse cx={466 + look} cy="276" rx="12" ry="15" fill="#866456"/>
            <ellipse cx={466 + look} cy="277" rx="5.2" ry="8.5" fill="#171628" stroke="none"/>
            <circle cx={462 + look} cy="272" r="3.4" fill="white" stroke="none"/>
          </g>
          <path d="M286 292Q316 312 350 297M433 294Q463 303 493 285" fill="none" stroke="#AA536F" strokeWidth="4.3"/>
        </g>
        <path d="M373 299Q365 325 362 341Q366 352 374 349M371 357Q381 367 389 358M397 360Q402 353 410 355" fill="none" stroke="#8F4750" strokeWidth="3.2"/>
        <path d="M310 327l4-1m7 3 3-1m6-4 3 1m112-2 4-1m7-4 4 1m7-5 3 1" stroke="#B76162" strokeWidth="2.8"/>
        <path d={mouth} fill="#421F34"/>
        <g clipPath={`url(#${id}-mouth)`} stroke="none">
          <path d={`M352 372L439 377L432 ${382 + open * 0.39}Q392 ${391 + open * 0.32} 351 390Z`} fill="#FFF1CE"/>
          <ellipse cx="391" cy={398 + open * 0.51} rx="26" ry="7" fill="#E97095"/>
        </g>
        <path d={`M377 ${399 + open}Q395 ${407 + open} 416 ${392 + open}`} fill="none" stroke="#B16564" strokeWidth="2.8"/>
        <path d="M226 319Q220 330 231 339Q242 346 247 334" fill="none" stroke="#FCDC86" strokeWidth="5"/>
        <path d="M246 334l2 15-7 5-4-6Z" fill="#FFC972" strokeWidth="1.8"/>

        <g transform={`translate(0 ${rub}) rotate(${rub / 2} 400 750)`}>
          <path d="M99 729Q126 708 154 724L274 765 307 748 335 761 337 809 305 855 231 876 139 853Q102 838 82 816Z" fill={`url(#${id}-skin)`}/>
          <path d="M103 785Q143 825 226 837L281 841 305 855Q269 875 231 876L139 853Q103 835 82 816Z" fill="#AE5C58" stroke="none"/>
          <path d="M709 732Q682 710 653 730L526 773 499 745 472 756 465 805 491 850 566 874 665 854Q702 842 721 819Z" fill={`url(#${id}-skin)`}/>
          <path d="M708 798Q674 830 578 845L527 847 503 855 567 874 665 854Q702 842 721 819Z" fill="#AD5A62" stroke="none"/>
          <path d={padEdge} fill={`url(#${id}-pad)`}/>
          <path d="M287 721Q303 705 334 712L456 713Q487 703 505 722" fill="none" stroke="#69748A" strokeWidth="3.2"/>
          <path d="M292 726l12-5 18 2m148-1 17-2 10 5" fill="none" stroke="#02E6E8" strokeWidth="4.9"/>
          <path d="M309 748H318V739H329V748H339V759H329V769H318V759H309Z" fill="#7C7A91" strokeWidth="2.6"/>
          <circle cx="359" cy="773" r="15" fill="#222333" stroke="#9790A6" strokeWidth="2.8"/>
          <circle cx="439" cy="773" r="15" fill="#222333" stroke="#9790A6" strokeWidth="2.8"/>
          <circle cx="472" cy="737" r="6" fill="#EBD572" strokeWidth="2"/>
          <circle cx="484" cy="750" r="6" fill="#FD6AA8" strokeWidth="2"/>
          <circle cx="459" cy="750" r="6" fill="#75BADE" strokeWidth="2"/>
          <circle cx="472" cy="762" r="6" fill="#71D7A0" strokeWidth="2"/>
          <path d="M380 732h39v14h-39z" fill="#515167" strokeWidth="2.4"/>
          <path d="M278 755Q271 738 285 730Q306 722 310 739Q312 748 297 754L285 761Q299 770 297 786L275 817 265 812H250L246 795Z" fill="#ECB080"/>
          <path d="M524 757Q531 738 516 730Q496 723 492 741Q492 751 505 756L515 764Q500 773 501 789L525 817 533 813 549 814 552 794Z" fill="#ECB080"/>
          <path d="M249 797l13-11m-9 23 17-13m380-38-10-3m-95 45-14-12m10 23-17-13" fill="none" stroke="#996153" strokeWidth="2.8"/>
        </g>
      </g>
    </svg>
  );
};

type AlligatorProps = {frame: number; fps: number; chomp?: boolean};
const upperTeeth = [[93,147], [120,150], [150,151], [180,150], [210,145], [233,139], [255,130]];
const lowerTeeth = [[95,153], [124,157], [154,157], [184,154], [214,149], [244,141]];

export const Alligator2D: React.FC<AlligatorProps> = ({frame, fps, chomp = true}) => {
  const id = `gator-${useId().replace(/[^\w-]/g, '')}`;
  const phase = frame % Math.round(fps * 2);
  const snap = spring({frame: phase, fps, config: {damping: 12, stiffness: 160}});
  const relax = interpolate(phase / fps, [0, 0.43, 1.35, 1.95], [0, 1, 1, 0], {extrapolateRight: 'clamp'});
  const gape = chomp ? 6 + 21 * snap * relax : 3;
  const jawAngle = -gape * Math.PI / 180;
  const jawPoint = (x: number, y: number) => {
    const dx = x - 281;
    const dy = y - 140;
    return `${281 + dx * Math.cos(jawAngle) - dy * Math.sin(jawAngle)} ${140 + dx * Math.sin(jawAngle) + dy * Math.cos(jawAngle)}`;
  };
  const mouthInterior = `M153 146Q206 132 252 123L293 137L${jawPoint(274, 155)}Q${jawPoint(218, 172)} ${jawPoint(176, 160)}Z`;
  return (
    <svg width="100%" height="100%" viewBox="0 0 620 352" xmlns="http://www.w3.org/2000/svg" aria-label="Аллигатор">
      <defs>
        <linearGradient id={`${id}-scale`} x2="0.8" y2="1" gradientUnits="objectBoundingBox">
          <stop stopColor="#A3BE67"/><stop offset=".44" stopColor="#688C57"/><stop offset="1" stopColor="#315450"/>
        </linearGradient>
      </defs>
      <g transform={`translate(0 ${2 * Math.sin(frame / fps * 5)})`} stroke={ink} strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round">
        <path d="M341 170Q388 114 454 116Q511 121 531 175Q551 232 504 255Q483 264 456 246Q485 238 482 217Q477 197 445 197L385 228Z" fill="#405E4E"/>
        <path d="M391 164q64-56 109 3q16 24 6 49m-90-69 15 9m12-17 15 10m20 0 14 14" stroke="#89A065" fill="none"/>
        <path d="M234 185Q277 120 369 137Q475 150 491 230Q469 284 406 292Q347 304 257 268Z" fill={`url(#${id}-scale)`}/>
        <path d="M279 212Q337 256 421 253L480 235Q451 284 400 287Q327 303 252 269Z" fill="#365A4F" stroke="none"/>
        <path d="M298 151l17-23 19 17 20-25 21 25 28-16 17 25 24-10 10 29" fill="#7C9961"/>
        <path d="M334 207l13-15 22 2 8 15-10 17-25-1Zm45-21 9-13 20 4 9 17-18 11-17-7Zm32 36 11-13 20 2 11 12-12 14-21 2Zm-110-13 9-17 23-2 7 16-14 15-16 2Z" fill="none" stroke="#A0B675" strokeWidth="2.5" opacity=".67"/>
        <path d="M407 239Q428 232 440 248Q445 262 434 278L449 303 439 314 419 310 407 316 394 310 391 285Z" fill="#648354"/>
        <path d="M264 236Q288 218 309 231Q328 252 316 276L332 305 321 316 305 312 293 321 278 315 275 293 251 273Z" fill="#719050"/>
        <path d="M279 314l-2 10 13-4m19-5 3 10 11-10m76-5-4 12 12-4m24-8 5 10 9-10" fill="#FFDC9D" strokeWidth="2.6"/>
        <path d={mouthInterior} fill="#3F2037"/>
        <g transform={`rotate(${-gape} 281 140)`}>
          <path d="M80 153Q124 149 157 155Q209 154 260 135Q279 129 293 147L287 171Q244 197 172 195Q116 190 83 180Q67 176 80 153Z" fill="#A09D62"/>
          <path d="M84 155Q122 153 158 159Q217 160 270 136Q272 162 228 174Q166 193 88 174Z" fill="#894B57"/>
          <path d="M102 167q52 14 101-4" fill="none" stroke="#E97E8F" strokeWidth="6"/>
          {lowerTeeth.map(([x, y], i) => <path key={x} d={`M${x} ${y + 5}l5 ${-9 - (i % 3) * 2} 6 12Z`} fill="#FFF1BD" strokeWidth="2.2"/>)}
        </g>
        {upperTeeth.map(([x, y], i) => <path key={x} d={`M${x} ${y}l4 ${13 + (i % 3) * 2} 8 -14Z`} fill="#FFF1C3" strokeWidth="2.2"/>)}
        <path d="M82 146Q67 143 69 128Q73 103 106 104Q157 107 212 99L235 80Q240 63 255 62Q285 64 286 91Q317 95 323 122Q325 142 302 160Q267 165 254 144Q210 160 164 157L104 154Z" fill={`url(#${id}-scale)`}/>
        <path d="M79 133Q112 132 139 139Q207 148 252 128Q287 146 309 133Q310 151 297 157Q264 164 254 144Q210 160 164 157L104 154Z" fill="#365649" stroke="none"/>
        <path d="M76 123Q103 108 119 110Q174 119 214 105M241 80q13-13 28-6" fill="none" stroke="#D9CC84" strokeWidth="3.8"/>
        <path d="M95 121q8-8 16 0q-8 7-16 0Zm118-6 8-3m-40 14 7-2m-28 3 6-1m-40 7 7 1" stroke="#1F3B45" fill="#1F3B45"/>
        <path d="M236 105Q246 87 271 91Q274 115 256 118Q242 118 236 105Z" fill="#F5B84C"/>
        <ellipse cx="257" cy="103" rx="2.7" ry="10" fill="#161521" stroke="none"/>
        <circle cx="253" cy="99" r="2.1" fill="#FFFAB2" stroke="none"/>
        <path d="M232 100q11-20 39-12" fill="none" stroke="#5C6845" strokeWidth="5"/>
        <path d="M280 113q14-8 24 2m-16 11 9-2m-13 15 9-3" fill="none" stroke="#9FAF6B" strokeWidth="2.7"/>
      </g>
    </svg>
  );
};
