import React, {useId} from 'react';
import {interpolate, spring} from 'remotion';

export type Mechanic = 'traffic' | 'tow' | 'chase' | 'npc' | 'eviction' | 'airboat' | 'skyline';

const pink = '#FF2E93';
const cyan = '#00F0FF';
const gold = '#FFD27F';
const outline = '#111111';
const extrapolate = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const range = (length: number) => Array.from({length}, (_, i) => i);

const Wheel: React.FC<{x: number; y: number; turn: number; size?: number}> = ({
  x, y, turn, size = 24,
}) => (
  <g transform={`translate(${x} ${y}) scale(${size / 24})`}>
    <circle r="24" fill="#100F1A" stroke={outline} strokeWidth="4" />
    <circle r="16" fill="#414865" stroke="#666C87" strokeWidth="2" />
    <g transform={`rotate(${turn})`} stroke="#B9C7D8" strokeWidth="2.5" strokeLinecap="round">
      {range(5).map((i) => <path key={i} transform={`rotate(${i * 72})`} d="M0 -4L5 -13" />)}
    </g>
    <circle r="4" fill="#E4DFF4" />
  </g>
);

const Coupe: React.FC<{color: string; shade: string; turn: number}> = ({color, shade, turn}) => (
  <g stroke={outline} strokeWidth="3.5" strokeLinejoin="round">
    <ellipse cx="153" cy="120" rx="151" ry="21" fill="#080615" opacity=".52" stroke="none" />
    <path d="M4 76L20 55 72 48 118 18Q125 13 137 13H186Q209 13 225 33L244 49 284 60Q298 64 304 79L310 108 296 119H18L2 103Z" fill={color} />
    <path d="M5 87L64 88 219 72 294 71 304 79 310 108 296 119H18L2 103Z" fill={shade} stroke="none" />
    <path d="M19 93Q70 100 102 92L248 75 298 77M97 58L230 52M113 111L226 97" stroke="#FEEAFF" strokeOpacity=".38" fill="none" strokeWidth="2.5" />
    <path d="M88 48L124 23Q131 19 143 19H184Q199 19 214 33L233 49Z" fill="#161B35" />
    <path d="M122 25L113 45 168 43 193 21" fill="#784E8F" opacity=".52" stroke="none" />
    <path d="M164 19L159 48M218 35L210 55M159 57L156 86M127 64H145" fill="none" />
    <path d="M291 74L302 78 305 87H280Z" stroke="none" fill={gold} />
    <path d="M5 79L25 76 29 82 7 89Z" stroke="none" fill="#FF3B30" />
    <path d="M277 108H308M9 106H26" stroke="#39364E" />
    <Wheel x={65} y={105} turn={turn} />
    <Wheel x={255} y={105} turn={turn} />
  </g>
);

const OverheadCar: React.FC<{color: string; x: number; y: number; angle: number}> = ({
  color, x, y, angle,
}) => (
  <g transform={`translate(${x} ${y}) rotate(${angle})`} stroke={outline} strokeWidth="2">
    <rect x="-17" y="-27" width="36" height="66" rx="11" fill="#07111F" opacity=".7" stroke="none" />
    <path d="M-16 -22Q-16 -34 -6 -35H6Q16 -34 16 -22V27Q16 34 8 34H-8Q-16 34 -16 27Z" fill={color} />
    <path d="M-13 -12L-10 -18H10L13 -12 11 17H-11Z" fill="#161A32" />
    <path d="M-9 -11H9V12H-9Z" fill={color} opacity=".62" stroke="none" />
    <path d="M-13 -25L-8 -29M8 -29L13 -25" stroke="#FFF6CE" strokeWidth="3" />
    <path d="M-13 27H-8M8 27H13" stroke="#FF3B30" strokeWidth="3" />
  </g>
);

const Badge: React.FC<{x: number; y: number; label: string; tone?: string; width?: number}> = ({
  x, y, label, tone = cyan, width = 244,
}) => (
  <g transform={`translate(${x} ${y})`}>
    <rect width={width} height="44" rx="12" fill="#1A162B" stroke={tone} strokeOpacity=".76" strokeWidth="2" />
    <circle cx="22" cy="22" r="4" fill={tone} />
    <text x="39" y="28" fontFamily="system-ui, sans-serif" fontWeight="900" fontSize="17" fill={tone}>{label}</text>
  </g>
);

const Block: React.FC<{x: number; y: number; w: number; h: number; hue: string}> = ({
  x, y, w, h, hue,
}) => (
  <g transform={`translate(${x} ${y})`}>
    <rect width={w} height={h} rx="24" fill="#35304C" stroke="#625477" strokeOpacity=".8" strokeWidth="2" />
    <rect x="14" y="16" width={w - 28} height={h - 32} rx="13" fill="#151629" stroke="#272C45" strokeWidth="3" />
    {range(3).map((i) => (
      <g key={i}>
        <rect x={27 + i * (w - 50) / 3} y={35 + i * 9} width={(w - 74) / 3} height={h - 83 - i * 7} rx="3" fill="#0A0B19" transform="translate(6 9)" />
        <rect x={27 + i * (w - 50) / 3} y={35 + i * 9} width={(w - 74) / 3} height={h - 83 - i * 7} rx="3" fill={i === 1 ? '#51415D' : '#302F4B'} stroke={hue} strokeOpacity=".35" strokeWidth="2" />
        <path d={`M${35 + i * (w - 50) / 3} ${47 + i * 9}h${(w - 113) / 3}`} stroke={hue} strokeWidth="2" opacity=".56" />
      </g>
    ))}
  </g>
);

const Traffic: React.FC<{frame: number; fps: number; variant: number}> = ({frame, fps, variant}) => {
  const start = spring({frame, fps, config: {damping: 12, stiffness: 160}});
  const stop = interpolate(frame, [0, 27, 69], [-64, 0, 6], extrapolate);
  const palette = [pink, '#F97316', cyan, '#A855F7', '#F6C351'];
  return (
    <g>
      <rect x="18" y="90" width="864" height="690" rx="44" fill="#17192C" stroke="#4C4866" strokeWidth="3" />
      <path d="M25 394H875V594H25Z M337 98H563V774H337Z" fill="#25213A" />
      <path d="M26 410H330M569 410H874M26 576H330M569 576H874M353 101V382M547 101V382M353 602V769M547 602V769" stroke="#6E698B" strokeWidth="3" />
      <path d="M28 474H331M566 474H875M410 102V382M492 603V770" stroke="#9C86AC" strokeWidth="2.5" strokeDasharray="14 19" opacity=".76" />
      <path d="M28 490H331M566 490H875M425 102V382M477 603V770" stroke="#DD9D57" strokeWidth="2.5" opacity=".56" />
      <Block x={29} y={103} w={301} h={279} hue={cyan} />
      <Block x={571} y={103} w={300} h={279} hue={pink} />
      <Block x={29} y={603} w={301} h={167} hue={pink} />
      <Block x={571} y={603} w={300} h={167} hue={cyan} />
      <g stroke="#D0CBDC" strokeWidth="5" opacity=".52">
        {range(7).map((i) => <path key={i} d={`M${364 + 28 * i} 390v29m0 153v29`} />)}
        {range(6).map((i) => <path key={i} d={`M330 ${425 + i * 28}h31m179 0h31`} />)}
      </g>
      <g>
        {range(4).map((i) => <OverheadCar key={i} x={57 + i * 82 + stop * .28} y={454} angle={90} color={palette[(i + variant) % palette.length]} />)}
        {range(4).map((i) => <OverheadCar key={i} x={853 - i * 83 - stop * .39} y={526} angle={-90} color={palette[(i + 1) % palette.length]} />)}
        {range(3).map((i) => <OverheadCar key={i} x={382} y={143 + i * 86 + stop * .3} angle={180} color={palette[(i + 3) % palette.length]} />)}
        {range(2).map((i) => <OverheadCar key={i} x={519} y={723 - i * 86 - stop * .2} angle={0} color={palette[(i + 2) % palette.length]} />)}
      </g>
      <g transform={`translate(449 490) scale(${0.94 + start * .06})`}>
        <circle r={52 + 12 * Math.sin(frame / 10)} fill="none" stroke={pink} strokeWidth="2" opacity=".48" />
        <path d="M-27 0h54M0 -27v54" stroke={pink} strokeWidth="1" opacity=".65" />
        {variant === 0 ? (
          <g transform={`translate(0 ${-14 * (1 - start)})`} strokeLinejoin="round">
            <path d="M-21 3L20 29m-36 0L19 1m-42 -15L-11 26m37 -43L12 24" stroke="#C4C5E9" strokeWidth="4" />
            <path d="M-26 -21L13 -29 24 -4 -17 8Z" fill="#EB4A94" stroke={outline} strokeWidth="3" />
            <ellipse cx="-1" cy="-14" rx="9" ry="13" fill="#CF9477" stroke={outline} strokeWidth="2" />
            <path d="M-11 -13Q-15 -26 -1 -28 11 -29 11 -17Z" fill="#3D2147" stroke={outline} strokeWidth="2" />
            <path d="M27 -16L59 -9 53 18 23 10Z" fill="#A1E997" stroke={outline} strokeWidth="2" />
            <path d="M33 -6l18 4m-19 1l16 4m-17 1l10 3" stroke="#335D43" strokeWidth="2" strokeLinecap="round" />
          </g>
        ) : (
          <path d="M0 -19L18 14H-18Z" fill={gold} stroke={outline} strokeWidth="3" strokeLinejoin="round" />
        )}
      </g>
      {variant === 0 ? (
        <Badge x={42} y={109} label="ПЛАТНЫЙ ПРОЕЗД" tone={pink} width={223} />
      ) : (
        <g>
          <path d="M75 522H305Q381 522 381 450V232Q381 215 403 215H709V160"
            fill="none" stroke="#0C1020" strokeWidth="13" strokeLinecap="round" />
          <path d="M75 522H305Q381 522 381 450V232Q381 215 403 215H709V160"
            fill="none" stroke={cyan} strokeWidth="6" strokeDasharray="12 16" strokeDashoffset={-frame * 1.1} strokeLinecap="round" />
          <g transform="translate(709 161)" strokeLinejoin="round">
            <circle r="31" fill="#201831" stroke={pink} strokeWidth="3" />
            <path d="M-18 -5H18Q16 11 7 13H-8Q-16 10 -18 -5Z" fill={gold} stroke={outline} strokeWidth="3" />
            <path d="M-8 -11l-3 -10m10 10v-12m7 13l3 -11" stroke="#FFA872" strokeWidth="3" strokeLinecap="round" />
          </g>
          <Badge x={42} y={109} label="МАРШРУТ ПЕРЕСТРОЕН" tone={cyan} width={279} />
        </g>
      )}
    </g>
  );
};

const Tow: React.FC<{frame: number; fps: number; variant: number}> = ({frame, fps, variant}) => {
  const hook = spring({frame: frame - 9, fps, config: {damping: 12, stiffness: 160}});
  const travel = interpolate(frame, [25, 100], [-138, 144], extrapolate);
  const rise = interpolate(hook, [0, 1], [30, 0], extrapolate);
  const driver = variant === 0 ? '#B7F57F' : '#8AF8ED';
  return (
    <g>
      <path d="M0 572L900 526V720H0Z" fill="#3A2A4A" stroke={outline} strokeWidth="4" />
      <path d="M0 612L900 574V716H0Z" fill="#1D1B30" />
      <path d="M0 683L900 646" stroke="#F4A451" strokeWidth="5" strokeDasharray="65 47" opacity=".62" />
      <g opacity=".73">
        <path d="M0 336L900 298V530L0 577Z" fill="#231D34" stroke="#443556" strokeWidth="4" />
        {range(8).map((i) => (
          <g key={i} transform={`translate(${25 + i * 115} ${356 - i * 4})`}>
            <path d="M0 4L92 0V142L0 148Z" fill="#102733" stroke="#786A87" strokeWidth="2" />
            <path d="M3 8L88 4V21L3 25Z" fill={i % 2 === 0 ? cyan : pink} fillOpacity=".32" />
            <path d="M45 6V144M2 75L89 69" stroke="#6C587B" strokeWidth="2" />
          </g>
        ))}
      </g>
      <g transform={`translate(${travel + 45} 456)`}>
        <g transform={`translate(0 ${88 + rise}) scale(.78) rotate(${-9 * hook} 230 100)`}>
          <Coupe color="#F64A9D" shade="#AA326E" turn={travel * 2} />
        </g>
        <path d={`M237 ${142 + rise * .6}Q270 ${174 - 17 * hook} 354 102`} stroke="#0A0913" strokeWidth="8" fill="none" />
        <path d={`M237 ${142 + rise * .6}Q270 ${174 - 17 * hook} 354 102`} stroke="#A5B7CC" strokeWidth="3" fill="none" />
        <circle cx="239" cy={142 + rise * .6} r="6" fill="none" stroke={gold} strokeWidth="3" />
        <g transform="translate(264 0)" stroke={outline} strokeWidth="3.5" strokeLinejoin="round">
          <ellipse cx="234" cy="152" rx="231" ry="25" fill="#090613" opacity=".54" stroke="none" />
          <path d="M23 111L146 32H230L227 46H154L52 111Z" fill={driver} />
          <path d="M71 109L193 40 198 109Z" fill="#152936" />
          <rect x="9" y="102" width="400" height="42" rx="7" fill="#5C7E49" />
          <path d="M210 106V81L226 22Q230 16 246 16H306Q326 18 335 36L352 63 410 72 433 93V135H210Z" fill={driver} />
          <path d="M210 95L430 98V135H210Z" fill="#507C52" stroke="none" />
          <path d="M227 62L239 29H305Q316 29 323 40L334 61Z" fill="#182E45" />
          <path d="M231 55L240 32H282L270 54Z" fill="#64C5C4" opacity=".52" stroke="none" />
          <path d="M280 28V104M292 75h30M424 89l-29 2 1 13h36" fill="none" />
          <rect x="245" y="1" width="45" height="14" rx="4" fill={gold} opacity={0.42 + 0.58 * Math.abs(Math.sin(frame / 4))} />
          <Wheel x={92} y={135} turn={travel * 2} size={28} />
          <Wheel x={170} y={135} turn={travel * 2} size={28} />
          <Wheel x={369} y={135} turn={travel * 2} size={28} />
        </g>
      </g>
      <Badge x={51} y={263} label={hook > .8 ? 'МАШИНА ЗАБРАНА' : 'ВЫЗВАН ЭВАКУАТОР'} tone={pink} width={253} />
    </g>
  );
};

const ChaseCar: React.FC<{color: string; dark: string; police?: boolean; frame: number}> = ({
  color, dark, police, frame,
}) => (
  <g stroke={outline} strokeWidth="3.5" strokeLinejoin="round">
    <ellipse cx="102" cy="132" rx="110" ry="25" fill="#0D0820" opacity=".71" stroke="none" />
    <path d="M13 74L37 53 55 14Q65 6 81 6H125Q138 6 150 15L173 51 194 71 207 121 187 142H17L0 120Z" fill={color} />
    <path d="M11 80L18 116 0 120 17 142H187L207 121 194 76 176 102H26Z" fill={dark} />
    <path d="M45 53L62 20Q66 16 80 16H124Q136 16 144 23L160 53Z" fill="#22223D" />
    <path d="M52 49L65 24H113L99 48Z" fill="#7E83B6" opacity=".66" stroke="none" />
    <path d="M26 73Q103 86 183 73L169 91Q103 102 38 90Z" fill="#322349" stroke="none" />
    <path d="M19 85L60 93 56 104 24 101ZM148 93L190 85 187 101 152 104Z" fill="#FF4C75" />
    <path d="M25 94L54 99m99 0l30 -5" stroke="#FF9BAC" strokeWidth="2" />
    <rect x="88" y="114" width="34" height="12" rx="3" fill="#F2DBE1" strokeWidth="2" />
    <path d="M36 131h21m92 0h20" stroke="#77758D" strokeWidth="4" />
    {police && (
      <>
        <rect x="71" y="0" width="63" height="13" rx="4" fill="#A3BEDF" />
        <path d="M75 5h23m9 0h22" strokeWidth="7" stroke={Math.floor(frame / 4) % 2 ? '#FF3B30' : cyan} />
        <ellipse cx="103" cy="141" rx="108" ry="13" fill={Math.floor(frame / 4) % 2 ? pink : cyan} opacity=".22" stroke="none" />
      </>
    )}
  </g>
);

const Chase: React.FC<{frame: number; fps: number; variant: number; id: string}> = ({
  frame, fps, variant, id,
}) => {
  const sweep = Math.sin(frame / 18);
  const distance = interpolate(frame, [0, 104], [0, -206], extrapolate);
  const kick = spring({frame, fps, config: {damping: 12, stiffness: 160}});
  return (
    <g clipPath={`url(#${id}-scene)`}>
      <path d="M22 829L395 309H518L880 829Z" fill="#241C39" stroke="#645874" strokeWidth="4" />
      <path d="M55 829L404 309M846 829L508 309" stroke={pink} strokeWidth="3" strokeOpacity=".57" />
      {range(11).map((i) => {
        const offset = ((i * .093 + frame * .009) % 1) ** 2;
        const y = 304 + offset * 530;
        const next = 304 + offset * 593;
        return <path key={i} d={`M${450 + offset * 2} ${y}L${450 + offset * 2} ${next}`} stroke={gold} strokeWidth={1 + offset * 9} opacity=".72" />;
      })}
      {range(6).map((i) => {
        const f = i / 5;
        const y = 362 + f * f * 395;
        const x = 392 - f * f * 315;
        return (
          <g key={i} stroke={i % 2 ? cyan : pink} strokeWidth={1 + 2 * f} opacity={.34 + f * .5}>
            <path d={`M${x} ${y}l-14 -${28 + 102 * f} -${17 + 28 * f} -6M${900 - x} ${y}l14 -${28 + 102 * f} ${17 + 28 * f} -6`} fill="none" />
            <path d={`M${x - 31 - 28 * f} ${y - 34 - 102 * f}h${22 + 21 * f}m${900 - 2 * x + 47 + 35 * f} 0h${22 + 21 * f}`} strokeWidth={3 + f * 3} />
          </g>
        );
      })}
      <g transform={`translate(${473 - sweep * 120} ${482 + distance * .5}) rotate(${sweep * -9}) scale(${0.81 - frame * .003})`}>
        <ChaseCar color={variant === 0 ? pink : '#F7A444'} dark={variant === 0 ? '#922354' : '#A34B46'} frame={frame} />
        <g transform={`translate(140 25) rotate(${-5 - sweep * 14})`} stroke={outline} strokeWidth="3" strokeLinejoin="round">
          <path d="M0 2L47 -5 63 11 17 20Z" fill="#FFE5A9" />
          <path d="M0 2L17 20V29L0 11ZM17 20L63 11V20L17 29Z" fill="#BD754D" />
          <path d="M23 9l17 -5 4 10Z" fill="#EE663D" strokeWidth="2" />
        </g>
      </g>
      <g transform={`translate(${328 + sweep * 103} ${618 - kick * 45}) rotate(${sweep * 8} 100 90) scale(1.22)`}>
        <ChaseCar color="#9194C3" dark="#34315D" police frame={frame} />
      </g>
      <path d="M99 770l45 -45m-67 79l25 -25m693 -22l-46 -43m73 -8l-27 -22" stroke={cyan} strokeWidth="4" opacity={.36 + .3 * Math.abs(sweep)} strokeLinecap="round" />
      <Badge x={50} y={271} label={variant === 0 ? 'ПОГОНЯ В ВАЙС-СИТИ' : 'МАРШРУТ ПЕРЕСТРОЕН'} tone={cyan} width={270} />
    </g>
  );
};

const Pedestrian: React.FC<{
  frame: number; offset: number; x: number; y: number; scale: number; coat: string; skin: string;
  item?: 'phone' | 'clipboard';
}> = ({frame, offset, x, y, scale, coat, skin, item}) => {
  const step = Math.sin(frame / 6.5 + offset);
  return (
    <g transform={`translate(${x} ${y + Math.abs(step) * 5}) scale(${scale})`} stroke={outline} strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round">
      <ellipse cy="227" rx="58" ry="12" stroke="none" fill="#0C0918" opacity=".65" />
      <path d={`M-24 127L-25 171 ${-23 + step * 28} 214H${-45 + step * 28}L-47 171 -44 125Z`} fill="#121927" />
      <path d={`M38 125L39 174 ${25 - step * 28} 215H${4 - step * 28}L12 177 8 130Z`} fill="#26283C" />
      <path d={`M${-42 + step * 28} 211Q${-15 + step * 28} 211 ${-7 + step * 28} 222L${-12 + step * 28} 227H${-50 + step * 28}Z M${9 - step * 28} 210Q${33 - step * 28} 211 ${43 - step * 28} 224L${39 - step * 28} 228H${3 - step * 28}Z`} fill="#E1CDE2" />
      <path d="M-21 63L-48 78 -52 127Q-30 141 -9 137L40 131 52 86 18 63Z" fill={coat} />
      <path d="M-19 73L-11 129 30 131 40 108 11 112 20 77Z" fill="#2A183A" opacity=".28" stroke="none" />
      <path d="M-47 81L-63 121 -54 157 -41 155 -43 123 -28 101M47 88L57 113 78 102 84 116 56 139 38 119" fill={coat} />
      <path d="M-56 151L-41 150 -38 164 -45 171 -54 165ZM76 104L89 99 97 104 93 115 83 118Z" fill={skin} />
      <path d="M-13 51L-17 67 0 82 17 67 14 48Z" fill={skin} />
      <path d="M-29 27Q-27 4 -3 1 26 -1 30 22L28 45Q24 67 3 69 -21 64 -28 48Z" fill={skin} />
      <path d="M-30 32Q-34 11 -19 3 -3 -8 13 -1 30 -6 35 13L31 27Q13 30 3 16L-18 25 -22 42Z" fill="#25192B" />
      <path d="M4 35h4m12 -2h4M13 53q4 2 8 -1" fill="none" stroke="#3E2333" strokeWidth="2.5" />
      {item === 'phone' && <rect x="84" y="78" width="14" height="28" rx="3" transform="rotate(13 91 92)" fill="#201C37" stroke={cyan} strokeWidth="2.5" />}
      {item === 'clipboard' && (
        <g transform="translate(82 89) rotate(14)" strokeWidth="2.5">
          <rect x="-3" y="-23" width="37" height="48" rx="3" fill="#664150" />
          <path d="M2 -18h27v36H2Z" fill="#FCEDD2" />
          <path d="M9 -19h15v5H9Z" fill={gold} />
          <path d="M7 -8h17M7 -1h17M7 7h14" stroke="#B15C72" />
          <path d="M13 16l10 -23" stroke="#4B2E4A" strokeWidth="3" />
        </g>
      )}
    </g>
  );
};

const Npc: React.FC<{frame: number; fps: number; variant: number}> = ({frame, fps, variant}) => {
  const reveal = spring({frame: frame - 18, fps, config: {damping: 12, stiffness: 160}});
  const near = interpolate(frame, [0, 104], [-54, 60], extrapolate);
  const cart = variant > 1;
  const actors = [
    {x: 185 + near * (cart ? 2.65 : 1), y: 414, color: '#E34C86', skin: '#CB895E', scale: 1.12, item: undefined},
    {x: 485 - near * .28, y: 390, color: '#15A49E', skin: '#E6A888', scale: 1.28, item: cart ? undefined : 'phone'},
    {x: 743 - near * .42, y: 370, color: '#8A5BE0', skin: '#8E5646', scale: 1.08, item: cart ? undefined : 'clipboard'},
  ] as const;
  const carStop = cart ? interpolate(frame, [0, 32, 37, 104], [0, -98, -107, -103], extrapolate) : 0;
  const car = (
    <g opacity=".72" transform={`translate(${530 + carStop} 271) scale(.92)`}>
      <Coupe color="#FF8446" shade="#9D4850" turn={carStop * 3} />
    </g>
  );
  return (
    <g>
      <path d="M0 540L900 467V768H0Z" fill="#332940" stroke={outline} strokeWidth="4" />
      <path d="M0 654L900 587V785H0Z" fill="#211E33" />
      <path d="M0 648L900 583" stroke="#F6B66F" strokeWidth="4" opacity=".56" />
      <path d="M20 579l875 -65M0 609l900 -70M187 533l89 78m192 -103l90 76m136 -91l83 75" stroke="#5C4D6B" strokeWidth="3" fill="none" />
      {car}
      {actors.slice().reverse().map((actor, i) => (
        <Pedestrian key={actor.color} frame={frame} offset={i * 1.8} x={actor.x}
          y={actor.y}
          scale={actor.scale} coat={actor.color} skin={actor.skin} item={actor.item} />
      ))}
      {!cart && reveal > 0 && (
        <g transform={`translate(${actors[1].x + 105} 341) scale(${reveal})`}>
          <path d="M-9 35L-29 51 -20 22Q-31 9 -15 -6 -1 -18 16 -6 31 5 28 19 24 37 -9 35Z" fill="#18172B" stroke={cyan} strokeWidth="3" />
          <path d="M-11 8h22v12h-22zM-4 8l3 -4h5l3 4" fill="none" stroke={cyan} strokeWidth="2.3" strokeLinejoin="round" />
          <circle cy="14" r="3" fill="none" stroke={cyan} strokeWidth="2" />
        </g>
      )}
      {cart && (
        <g transform={`translate(${actors[0].x + 99} 521) rotate(${2 * Math.sin(frame / 4)})`} stroke={outline} strokeWidth="3" strokeLinejoin="round">
          <path d="M22 75L43 89H101L113 83M-8 10H7L24 74 108 68" fill="none" stroke="#C4E2E2" strokeWidth="6" />
          <path d="M8 20L129 11 114 60 22 70Z" fill="#A9D5D1" stroke="#212A39" />
          <path d="M12 31l114 -9m-110 23l105 -8m-101 20l97 -7m-86 -31l12 48m7 -50l11 49m9 -51l8 47m10 -48l4 46m17 -47l-5 44" fill="none" stroke="#4D6B76" strokeWidth="3" />
          <Wheel x={44} y={86} size={9} turn={frame * 9} />
          <Wheel x={99} y={87} size={9} turn={frame * 9} />
        </g>
      )}
      <Badge x={53} y={300} label={cart ? 'ТЕЛЕЖКА ИМЕЕТ ПРИОРИТЕТ' : 'ШТРАФ ВЫПИСАН'} tone={cyan} width={cart ? 322 : 224} />
    </g>
  );
};

const Eviction: React.FC<{frame: number; fps: number; variant: number}> = ({frame, fps, variant}) => {
  const slam = spring({frame: frame - 13, fps, config: {damping: 12, stiffness: 160}});
  const lock = spring({frame: frame - 29, fps, config: {damping: 12, stiffness: 160}});
  const angle = interpolate(slam, [0, 1], [0, 1], extrapolate);
  const left = 470 - angle * 158;
  const right = 546 - angle * 14;
  return (
    <g>
      <ellipse cx="457" cy="710" rx="385" ry="56" fill="#100D20" opacity=".68" />
      <path d="M121 393L218 272 645 251 776 376V669L118 710Z" fill="#674189" stroke={outline} strokeWidth="5" strokeLinejoin="round" />
      <path d="M119 400L119 710 309 694V381Z" fill="#433257" stroke={outline} strokeWidth="3" />
      <path d="M309 381L778 367V670L309 695Z" fill="#975989" stroke={outline} strokeWidth="3.5" />
      <path d="M82 397L211 239 645 217 805 366 783 402 305 423Z" fill="#232036" stroke={outline} strokeWidth="5" strokeLinejoin="round" />
      <path d="M82 397L210 239 305 423 783 402M223 256l423 -21 133 131" fill="none" stroke={pink} strokeOpacity=".5" strokeWidth="3" />
      <path d="M142 438L279 421V664L142 682Z" fill="#3B284D" stroke="#795B84" strokeWidth="3" />
      <path d="M558 415L752 409V554L558 563Z" fill="#352E53" stroke={outline} strokeWidth="5" />
      <path d="M573 425L739 419V541L573 549Z" fill="#A6E2D3" fillOpacity=".8" stroke="#201D32" strokeWidth="3" />
      <path d="M574 528L642 426 694 421 615 544Z" fill="#E6F6D9" opacity=".32" />
      <path d="M655 422V546M574 485l163 -7" stroke="#45435D" strokeWidth="4" />
      <path d="M311 444L537 433V678L311 692Z" fill="#1D162C" stroke={outline} strokeWidth="5" />
      <path d={`M309 443L${right} 433 ${right} 677 ${left} 689 309 692Z`} opacity={angle} fill="#21172E" />
      <path d={`M533 435L${left} ${470 - angle * 25}V${649 + angle * 43}L533 677Z`} fill="#53405E" stroke={outline} strokeWidth="4" />
      <path d={`M524 448L${left + 9} ${479 - angle * 21}V${584 + angle * 25}L524 596Z`} fill="#9B678E" stroke="#362240" strokeWidth="3" />
      <circle cx={left + 23} cy={618 + angle * 11} r={4 + angle * 4} fill={gold} stroke={outline} strokeWidth="2.5" />
      <path d="M309 693L536 677 570 697 311 722 274 708Z" fill="#604B68" stroke={outline} strokeWidth="4" />
      <g transform={`translate(${682 - angle * 111} ${619 + angle * 11}) rotate(${-20 + angle * 13})`} stroke={outline} strokeWidth="4" strokeLinejoin="round">
        <path d="M-49 0h36l10 -9 12 3 10 -5 17 5 1 8 -16 5 -8 -5 -8 5 -18 -5 -34 4Z" fill={gold} />
        <circle cx="39" cy="1" r="22" fill="#E7B764" />
        <circle cx="44" cy="0" r="8" fill="#71526F" />
        <path d="M-45 0l28 1" stroke="#FFE8AF" strokeWidth="2" />
      </g>
      {lock > 0 && (
        <g transform={`translate(418 546) scale(${lock})`} stroke={outline} strokeWidth="4" strokeLinejoin="round">
          <circle r="58" fill="#21152B" stroke={pink} strokeWidth="2" />
          <path d="M-19 -8v-15a19 19 0 1 1 38 0v15" fill="none" stroke={gold} strokeWidth="8" />
          <rect x="-27" y="-10" width="54" height="42" rx="8" fill={pink} />
          <path d="M0 6v12" stroke="#461B42" strokeWidth="7" strokeLinecap="round" />
          <circle cx="49" cy="-43" r="21" fill="#A63461" stroke="#FF7A70" strokeWidth="2" />
          <path d="M41 -51l16 16m0 -16L41 -35" stroke="#FFF0EF" strokeWidth="5" strokeLinecap="round" />
        </g>
      )}
      <Badge x={52} y={186} label={variant === 0 ? 'УБЕЖИЩЕ ЗАКРЫТО' : 'КЛЮЧ НЕ ПОДХОДИТ'} tone={pink} width={262} />
    </g>
  );
};

const Mangrove: React.FC<{x: number; y: number; scale: number; dark?: boolean}> = ({x, y, scale, dark}) => (
  <g transform={`translate(${x} ${y}) scale(${scale})`} fill={dark ? '#163338' : '#296C60'} stroke={dark ? '#153139' : '#2D5A4D'}>
    <path d="M0 0Q9 -32 -3 -78m5 53q15 -23 22 -45M0 -45Q-19 -58 -31 -58M1 -14L-15 2M3 -19L17 2" fill="none" strokeWidth="7" strokeLinecap="round" />
    <path d="M-44 -49Q-57 -68 -40 -77 -39 -91 -17 -86 -9 -101 10 -93 29 -96 42 -83 58 -79 51 -62 40 -53 26 -54 12 -48 -4 -53 -24 -46 -44 -49Z" strokeLinejoin="round" strokeWidth="3" />
  </g>
);

const WaitingBoat: React.FC<{x: number; y: number; scale: number; frame: number; color: string}> = ({
  x, y, scale, frame, color,
}) => (
  <g transform={`translate(${x} ${y + 2 * Math.sin(frame / 10 + x)}) scale(${scale})`} stroke={outline} strokeWidth="5" strokeLinejoin="round">
    <path d="M-78 80L128 61 135 70 104 91H-55Z" fill={color} />
    <path d="M-35 76l16 -44h19L22 76" fill="#82958C" />
    <path d="M50 69V26h21l13 40M61 56l43 -16" fill="none" stroke="#442D49" strokeWidth="8" />
    <circle cx="-22" cy="28" r="37" fill="#1D3044" stroke="#AEC5C9" />
    <path transform={`rotate(${frame * 24} -22 28)`} d="M-24 28l-15 -24 9 -12 14 12 -1 24 16 21 -8 13 -15 -11Z" fill="#ACC5C4" />
    <path d="M-58 28h73m-37 -37v74" stroke="#515375" strokeWidth="4" />
  </g>
);

const Airboat: React.FC<{frame: number; fps: number; variant: number; id: string}> = ({
  frame, fps, variant, id,
}) => {
  const position = interpolate(frame, [0, 52, 67, 104], [-195, 59, 80, 75], extrapolate);
  const angle = Math.sin(frame / 9) * 3;
  const splash = spring({frame, fps, config: {damping: 12, stiffness: 160}});
  return (
    <g clipPath={`url(#${id}-scene)`}>
      <path d="M0 440Q228 414 430 448 648 426 900 442V820H0Z" fill={`url(#${id}-lagoon)`} />
      <path d="M0 428Q142 410 329 448 522 429 678 441 797 409 900 432V474Q618 444 379 479 128 451 0 488Z" fill="#253B42" />
      {range(9).map((i) => <Mangrove key={i} x={i * 112 - 9} y={444 - (i % 3) * 6} scale={.42 + (i % 4) * .1} dark />)}
      <g stroke="#78D6CF" strokeWidth="2" fill="none" opacity=".49">
        {range(13).map((i) => (
          <path key={i} d={`M${(i * 179 + frame * -1.2 + 1250) % 950 - 40} ${484 + i * 23}q36 -4 79 0`} />
        ))}
      </g>
      <WaitingBoat x={687} y={482} scale={.72} frame={frame} color="#DA62A2" />
      <WaitingBoat x={818} y={460} scale={.59} frame={frame} color="#A0DCD1" />
      <WaitingBoat x={897} y={443} scale={.5} frame={frame} color="#F4BE79" />
      <g transform={`translate(${position + 300} 548)`}>
        <g fill="none" strokeLinecap="round">
          {range(5).map((i) => (
            <path key={i} d={`M${40 - i * 20} ${90 + i * 7}q-${118 + i * 30} ${25 + i * 4} -${229 + i * 37} ${18 + i * 14}`}
              stroke={i % 2 ? cyan : '#C0F6E0'} strokeWidth={6 - i * .7} opacity={.8 - i * .13} />
          ))}
        </g>
        {range(17).map((i) => {
          const time = ((frame + i * 7) % 36) / 36;
          const x = 65 - i * 9 - time * 205;
          const y = 104 - 35 * Math.sin(time * Math.PI) + i * .4;
          return <circle key={i} cx={x} cy={y} r={(2 + i % 4) * (1 - time)} fill="#C4FEED" opacity={(1 - time) * splash} />;
        })}
        <g transform={`rotate(${angle} 142 70)`} stroke={outline} strokeWidth="3.5" strokeLinejoin="round">
          <ellipse cx="148" cy="111" rx="161" ry="15" fill="#061E27" opacity=".64" stroke="none" />
          <path d="M-17 77H238L297 64 283 88Q260 108 215 108H24Q-3 104 -17 77Z" fill={variant ? '#EF5185' : '#F99A56'} />
          <path d="M-13 91H225Q264 87 288 80L273 96 225 107H28Q4 107 -13 91Z" fill="#674264" stroke="none" />
          <path d="M14 74L40 25H86L103 74Z" fill="#444962" />
          <circle cx="62" cy="10" r="56" fill="#233044" fillOpacity=".7" stroke="#141821" strokeWidth="7" />
          <circle cx="62" cy="10" r="47" fill="none" stroke="#95BFC0" strokeWidth="2" />
          <g transform={`rotate(${frame * 28} 62 10)`}>
            <path d="M57 11Q32 -9 40 -28 54 -36 67 6 88 26 84 43 70 53 57 11Z" fill="#BBD9D2" strokeWidth="2" />
          </g>
          <path d="M62 -46v112M6 10h112M23 -29l78 78m0 -78L23 49" stroke="#2A4E53" strokeWidth="2.3" opacity=".85" />
          <circle cx="62" cy="10" r="7" fill={cyan} />
          <path d="M133 76V37H145L168 72M182 73L200 46 218 44" fill="none" strokeWidth="6" />
          <path d="M128 56L145 49 181 64 197 72H161L143 66 133 76 117 75Z" fill="#F07BB7" />
          <path d="M138 28Q151 11 169 22L180 39 199 38 203 47 175 54 153 43 147 53 128 54Z" fill="#13A198" />
          <path d="M151 15L166 14 167 26 155 31 147 26Z" fill="#CC8A69" />
          <path d="M144 15Q138 4 154 -1 166 -4 174 7L170 19 147 22Z" fill="#27213B" />
          <path d="M242 74L275 65M228 76l-20 2" stroke={gold} strokeWidth="2.5" />
        </g>
      </g>
      <Mangrove x={25} y={789} scale={1.27} dark />
      <Mangrove x={873} y={802} scale={1.18} />
      <Badge x={53} y={370} label={frame < 62 ? "БОЛОТА ЛЕОНИДЫ" : "ЛОДКИ В ПРОБКЕ"} tone={cyan} width={240} />
    </g>
  );
};

const Skyline: React.FC<{frame: number; fps: number; variant: number; id: string}> = ({
  frame, fps, variant, id,
}) => {
  const drift = interpolate(frame, [0, 104], [34, -55], extrapolate);
  const intro = spring({frame, fps, config: {damping: 12, stiffness: 160}});
  const points = [{x: 241, y: 463}, {x: 404, y: 371}, {x: 567, y: 404}];
  return (
    <g clipPath={`url(#${id}-scene)`}>
      <circle cx="682" cy="338" r="171" fill={`url(#${id}-sun)`} opacity=".74" />
      <g transform={`translate(${drift * .35} 0)`}>
        {range(19).map((i) => {
          const x = i * 57 - 52;
          const h = 80 + (i * 87) % 248;
          return <path key={i} d={`M${x} 635V${612 - h}h39l12 14v${h + 9}Z`} fill={i % 2 ? '#343154' : '#262541'} />;
        })}
      </g>
      <path d="M0 635L900 604V833H0Z" fill={`url(#${id}-lagoon)`} />
      <g transform={`translate(${drift} 0)`}>
        {range(11).map((i) => {
          const x = i * 104 - 77;
          const h = 84 + (i * 61) % 211;
          const y = 614 - h;
          const accent = i % 2 ? pink : cyan;
          return (
            <g key={i}>
              <path d={`M${x} 640V${y}h61l21 19v${h + 6}Z`} fill={i % 2 === 0 ? '#201B39' : '#2D2444'} stroke="#17162A" strokeWidth="3" />
              <path d={`M${x + 61} ${y}l21 19v${h + 6}h-21Z`} fill="#18162D" />
              <path d={`M${x + 6} ${y + 9}h51`} stroke={accent} strokeWidth="3" opacity=".79" />
              {range(Math.floor(h / 17) - 1).map((j) => (
                <path key={j} d={`M${x + 10} ${y + 28 + j * 16}h8m9 0h8m9 0h7`} stroke={j % 3 ? accent : gold}
                  strokeWidth="2.5" opacity={.3 + ((j + i) % 4) * .15} />
              ))}
            </g>
          );
        })}
      </g>
      <path d="M0 693L217 635 388 627 534 647 900 752" fill="none" stroke="#151529" strokeWidth="28" />
      <path d="M0 683L217 627 388 619 534 639 900 743" fill="none" stroke="#B37D9D" strokeWidth="4" />
      <path d="M142 652V701m234 -79v56m257 -9v60m177 -9v62" stroke="#1E2037" strokeWidth="9" />
      <path d="M615 746l208 58M111 720L9 743" stroke={pink} strokeWidth="2" opacity=".53" strokeDasharray="27 21" />
      <g transform={`translate(789 756) rotate(${Math.sin(frame / 29) * 2})`} fill="#201832" stroke={outline} strokeWidth="3" strokeLinejoin="round">
        <path d="M-12 17Q-27 -199 15 -399l21 5Q2 -191 18 17Z" fill="#3B294A" />
        <path d="M15 -399Q-83 -463 -141 -418 -101 -427 17 -383 -93 -397 -139 -355 -69 -377 24 -381 -16 -343 -6 -286 11 -339 29 -376 70 -356 110 -309 99 -371 37 -390 114 -406 139 -385 112 -447 25 -405 60 -461 100 -457 52 -478 15 -399Z" />
        <path d="M-5 -7l17 -4m-20 -33l17 -2m-20 -32l18 -3m-19 -33l18 -3m-15 -37l18 -1m-15 -39l19 -3m-14 -32l16 -3m-12 -33l17 -3m-11 -37l18 -3m-12 -30l17 -4" fill="none" stroke="#735483" strokeWidth="3" />
      </g>
      {points.map(({x, y}, i) => {
        const pulse = ((frame + i * 16) % 34) / 34;
        return (
          <g key={x} transform={`translate(${x + drift} ${y + 4 * Math.sin(frame / 13 + i)}) scale(${intro})`} fill={i % 2 ? pink : cyan}>
            <circle r={12 + 41 * pulse} fill="none" stroke={i % 2 ? pink : cyan} strokeWidth="2" opacity={.85 - pulse * .78} />
            <rect x="-51" y="-36" width="102" height="72" rx="8" fill="#241A3C" stroke={i % 2 ? pink : cyan} strokeWidth="2" />
            <circle cy="-12" r="12" fill={['#EAB27D', '#A5675F', '#DE977D'][i]} />
            <path d="M-20 21Q-20 6 0 5 20 6 20 21Z" fill={['#525489', '#D64E9B', '#1A9A9E'][i]} />
            <path d="M-12 -15Q-8 -32 7 -24L13 -14Z" fill="#352540" />
            <circle cx="38" cy="23" r="4" fill="#4ADE80" />
          </g>
        );
      })}
      <Badge x={51} y={246} label={variant === 0 ? 'ОФИС ПОД ПАЛЬМОЙ' : 'НОВЫЕ СОБЫТИЯ НА КАРТЕ'} tone={cyan} width={304} />
    </g>
  );
};

export const Mechanics: React.FC<{kind: Mechanic; frame: number; fps: number; variant?: number}> = ({
  kind, frame, fps, variant = 0,
}) => {
  const id = `mechanic-${useId().replace(/[^a-zA-Z0-9_-]/g, '')}`;
  const props = {frame, fps, variant, id};
  const set = {
    traffic: <Traffic {...props} />,
    tow: <Tow {...props} />,
    chase: <Chase {...props} />,
    npc: <Npc {...props} />,
    eviction: <Eviction {...props} />,
    airboat: <Airboat {...props} />,
    skyline: <Skyline {...props} />,
  };
  return (
    <svg viewBox="0 0 900 880" role="img" aria-label="Анимированная сцена Вайс-Сити"
      style={{width: '100%', height: '100%', display: 'block', overflow: 'visible'}}>
      <defs>
        <clipPath id={`${id}-scene`}><rect width="900" height="880" rx="22" /></clipPath>
        <linearGradient id={`${id}-lagoon`} x1="0" x2="0" y1="0" y2="1">
          <stop stopColor="#2B6E72" /><stop offset="1" stopColor="#102A43" />
        </linearGradient>
        <radialGradient id={`${id}-sun`}>
          <stop stopColor="#FFDA84" stopOpacity=".98" />
          <stop offset=".33" stopColor="#FF8A00" stopOpacity=".67" />
          <stop offset="1" stopColor="#FF2A85" stopOpacity="0" />
        </radialGradient>
      </defs>
      {set[kind]}
    </svg>
  );
};
