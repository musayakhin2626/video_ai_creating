import {interpolate, spring} from "remotion";
import type {CaptionTiming} from "../timeline";

type SubtitlesProps = {
  timings: readonly CaptionTiming[];
  keyword: string;
  frame: number;
  fps: number;
  cyan?: boolean;
};

const emphasizedWord = (line: string, keyword: string) => {
  const index = line.toLocaleLowerCase("ru").indexOf(keyword.toLocaleLowerCase("ru"));
  if (index >= 0) {
    return [line.slice(0, index), line.slice(index, index + keyword.length), line.slice(index + keyword.length)];
  }
  const match = /([\p{L}\p{N}]+)([^\p{L}\p{N}]*)$/u.exec(line);
  return match ? [line.slice(0, match.index), match[1], match[2]] : [line, "", ""];
};

export const Subtitles = ({timings, keyword, frame, fps, cyan}: SubtitlesProps) => {
  const active = timings.find(({startFrame, durationInFrames}) => frame >= startFrame && frame < startFrame + durationInFrames);
  if (!active) return null;

  const entry = frame - active.startFrame;
  const pop = spring({frame: entry, fps, config: {damping: 12, stiffness: 160}});
  const scale = interpolate(pop, [0, 0.7, 1], [1, 1.06, 1]);
  const [before, strong, after] = emphasizedWord(active.text, keyword);
  return (
    <div className="subtitle">
      {before}
      <span className={cyan ? "cyan" : "pink"} style={{display: "inline-block", transform: `scale(${scale})`}}>
        {strong}
      </span>
      {after}
    </div>
  );
};
