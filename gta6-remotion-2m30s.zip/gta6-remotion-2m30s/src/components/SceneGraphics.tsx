import type {CSSProperties, ReactNode} from "react";
import {interpolate, spring} from "remotion";
import type {Shot} from "../story";
import {Alligator2D, Character2D} from "./Character2D";
import {Mechanics, type Mechanic} from "./Mechanics";
import {UiCards, type CardKind} from "./UiCards";

type Motion = {frame: number; fps: number};
type SceneMotion = Motion & {phaseFrame: number; localFrame: number; durationInFrames: number};
type PropStyle = CSSProperties & {left: number; top: number; width: number; height: number};
type CameraMove = "zoom" | "pan" | "shake";
const clamped = {extrapolateLeft: "clamp", extrapolateRight: "clamp"} as const;
const springConfig = {damping: 12, stiffness: 160};

const attentionMoves: Partial<Record<Shot, CameraMove>> = {
  hook: "shake", papers: "shake", router: "zoom", office: "pan", school: "zoom",
  pizza: "pan", shelves: "pan", boxes: "shake", character: "zoom", relation: "zoom",
  tow: "pan", eviction: "shake", dog: "pan", keys: "shake", npc1: "pan",
  traffic: "shake", airboat: "pan", npc2: "pan", shop: "shake", scanner: "zoom",
  chat: "zoom", sales: "zoom", phone: "shake", skyline: "pan", tired: "zoom",
  poll: "zoom", chase: "shake", radar: "pan", return: "shake", loop: "zoom",
};

const cameraAccent = (shot: Shot, phaseFrame: number, fps: number, direction: number) => {
  const time = phaseFrame / fps;
  const response = spring({frame: phaseFrame, fps, config: springConfig});
  const easeOut = interpolate(time, [0, .45, 1.35], [1, 1, .28], clamped);
  const tension = response * easeOut;
  switch (attentionMoves[shot]) {
    case "pan":
      return {x: direction * tension * 58, y: -tension * 13, scale: tension * .04, roll: direction * tension * 1.3};
    case "shake": {
      const decay = interpolate(time, [0, .27, .53], [1, .66, 0], clamped);
      const vibration = Math.sin(phaseFrame * 1.75) * Math.max(0, response) * decay;
      return {x: vibration * 26, y: vibration * 9 - tension * 7, scale: tension * .038, roll: vibration * 1.9};
    }
    default:
      return {x: direction * tension * 16, y: -tension * 39, scale: tension * .12, roll: 0};
  }
};

const Prop = ({children, style}: {children: ReactNode; style: PropStyle}) => (
  <div className="prop" style={style}>{children}</div>
);

const HookGraphic = ({
  frame, fps, localFrame, phaseFrame, shot, settle = 1,
}: Omit<SceneMotion, "durationInFrames"> & {shot: "hook" | "return" | "loop"; settle?: number}) => {
  const incoming = shot === "return";
  const punch = spring({frame: localFrame, fps, config: springConfig});
  const zoom = .13 * punch * interpolate(localFrame / fps, [0, .27, .87], [1, 1, 0], clamped);
  const shake = Math.sin(localFrame * 1.9) * interpolate(localFrame / fps, [0, .33, 1.17, 2.33], [0, 6, 3, 0], clamped);
  const accent = cameraAccent(shot, phaseFrame, fps, incoming ? 1 : -1);
  const reacts = phaseFrame >= 2 && settle > .5;
  return (
    <div className="stage" style={{transform: `translate(${settle * (shake + accent.x)}px,${settle * accent.y}px) rotate(${settle * accent.roll}deg) scale(${1 + settle * (zoom + accent.scale)})`}}>
      <Prop style={{left: 296, top: 589, width: 741, height: 846}}>
        <Character2D frame={frame} fps={fps} mood={reacts ? (incoming ? "panic" : "focused") : (incoming ? "tired" : "panic")} speaking />
      </Prop>
      <Prop style={{left: -8, top: 752, width: 483, height: 520, transform: `rotate(${-10 + settle * shake * .6}deg)`}}>
        <UiCards kind="phone" frame={incoming ? frame : frame + 65} fps={fps} variant={incoming ? 1 : 0} />
      </Prop>
      {!incoming && <div className="hook-alert">БОСС: 20 ПРОПУЩЕННЫХ</div>}
      <Prop style={{left: 441, top: 1046, width: 632, height: 358}}>
        <Alligator2D frame={frame + 14} fps={fps} chomp={!incoming || reacts} />
      </Prop>
    </div>
  );
};

type PanelScene = {kind: CardKind; variant?: number; x?: number; y?: number; size?: number; tilt?: number};
const panels: Partial<Record<Shot, PanelScene>> = {
  papers: {kind: "papers", y: 530, size: 970, tilt: -3},
  router: {kind: "router", y: 468, size: 1020, tilt: 1},
  office: {kind: "office", y: 518, size: 898},
  school: {kind: "school", x: 72, y: 510, size: 930, tilt: -2},
  pizza: {kind: "pizza", x: 42, y: 522, size: 986, tilt: 3},
  shelves: {kind: "shelves", y: 501, size: 1000},
  boxes: {kind: "boxes", variant: 1, x: 66, y: 493, size: 950, tilt: -4},
  relation: {kind: "relationship", x: 49, y: 521, size: 990, tilt: 2},
  dog: {kind: "dog", x: 53, y: 516, size: 950},
  keys: {kind: "keys", variant: 1, y: 512, size: 976, tilt: -2},
  scanner: {kind: "scanner", variant: 1, x: 63, y: 492, size: 962, tilt: 2},
  chat: {kind: "chat", variant: 1, x: 71, y: 566, size: 936, tilt: -5},
  sales: {kind: "sales", y: 563, size: 968},
  phone: {kind: "phone", variant: 2, x: 83, y: 493, size: 923, tilt: 4},
  poll: {kind: "poll", variant: 1, x: 48, y: 546, size: 992, tilt: 1},
};

type StreetScene = {kind: Mechanic; variant?: number; tilt?: number; y?: number};
const streets: Partial<Record<Shot, StreetScene>> = {
  tow: {kind: "tow", tilt: -3, y: 483},
  eviction: {kind: "eviction", y: 474},
  npc1: {kind: "npc", variant: 1, tilt: 4, y: 474},
  traffic: {kind: "traffic", tilt: -1, y: 467},
  airboat: {kind: "airboat", tilt: 2, y: 487},
  npc2: {kind: "npc", variant: 2, tilt: -4, y: 469},
  skyline: {kind: "skyline", y: 505},
  chase: {kind: "chase", tilt: 4, y: 477},
  radar: {kind: "traffic", variant: 2, tilt: -3, y: 514},
};

const CharacterShot = ({frame, fps, sleepy, phaseFrame}: Motion & {sleepy: boolean; phaseFrame: number}) => {
  const badge = interpolate(frame, [40, 65, 104], [0, 0, 420], clamped);
  const reacts = phaseFrame >= 2;
  const mood = sleepy ? (reacts ? "focused" : "tired") : (reacts ? "smug" : "focused");
  const eyebrowBeat = spring({frame: phaseFrame, fps, config: springConfig});
  return (
    <>
      <Prop style={{left: sleepy ? 160 : 124, top: 560, width: 823, height: 887}}>
        <Character2D frame={frame} fps={fps} mood={mood} speaking />
      </Prop>
      <div className="status" style={{left: 86, top: 920, transform: `translateY(${sleepy ? badge : -eyebrowBeat * 13}px) rotate(${-9 + eyebrowBeat * 12}deg)`, color: sleepy ? "#ffb8d9" : "#4ade80"}}>
        {sleepy ? "ПРОПУСК" : "В СЕТИ"}
      </div>
    </>
  );
};

const ShopAction = ({frame, fps}: Motion) => {
  const trajectory = interpolate(frame, [0, 30, 63, 104], [-75, -75, 540, 685], clamped);
  const height = interpolate(frame, [0, 30, 48, 80], [0, 0, -235, 0], clamped);
  return (
    <>
      <Prop style={{left: -98, top: 885, width: 725, height: 412}}>
        <Alligator2D frame={frame} fps={fps} />
      </Prop>
      <svg viewBox="0 0 1080 1400" width="1080" height="1400" aria-label="Коробка пересекает луч кассового сканера">
        <path d="M655 1060h381l-67 114H574Z" fill="#3e284d" stroke="#111111" strokeWidth="3.5" />
        <path d="M781 1075h144l-32 57H749Z" fill="#1c182b" stroke="#a76fbf" strokeWidth="3.5" />
        <path d="M832 1102 809 805 916 1077Z" fill="#ff3b30" opacity={.26 + .12 * Math.cos(frame * .35)} />
        <path d="M812 1104 833 912l70 171" fill="none" stroke="#ff7a70" strokeWidth="6" opacity=".8" />
        <g transform={`translate(${329 + trajectory} ${935 + height}) rotate(${frame * 3} 55 42)`}>
          <path d="M0 12 84 0l43 34-86 14Z" fill="#ffcb78" stroke="#111111" strokeWidth="3.5" />
          <path d="M0 12 41 48v64L0 79Z" fill="#c58657" stroke="#111111" strokeWidth="3.5" />
          <path d="M41 48 127 34v64l-86 14Z" fill="#b25d45" stroke="#111111" strokeWidth="3.5" />
          <path d="M78 47v30l21-5V43Z" fill="#fff2cf" />
          <path d="M84 50v20m5-21v21m5-24v22" stroke="#121024" strokeWidth="2.2" />
        </g>
      </svg>
    </>
  );
};

export const SceneGraphics = ({shot, frame, fps, phaseFrame, localFrame, durationInFrames}: SceneMotion & {shot: Shot}) => {
  if (shot === "hook" || shot === "loop" || shot === "return") {
    const looping = shot === "loop";
    const lastFrame = durationInFrames - 1;
    const timerStart = Math.max(0, durationInFrames - 3 * fps);
    const timerFrame = interpolate(localFrame, [timerStart, lastFrame], [0, 104], clamped);
    const settleStart = Math.max(0, lastFrame - Math.round(.77 * fps));
    const settle = looping ? interpolate(localFrame, [settleStart, lastFrame], [1, 0], clamped) : 1;
    const hookFrame = frame * settle;
    return (
      <>
        <HookGraphic frame={hookFrame} fps={fps} shot={shot} localFrame={localFrame} phaseFrame={phaseFrame} settle={settle} />
        {looping && localFrame >= timerStart && localFrame < lastFrame && (
          <Prop style={{left: 188, top: 471, width: 710, height: 602, zIndex: 6, opacity: interpolate(timerFrame, [0, 8, 97, 104], [.88, 1, 1, 0], clamped)}}>
            <UiCards kind="timer" frame={timerFrame} fps={30} />
          </Prop>
        )}
      </>
    );
  }

  const panel = panels[shot];
  const street = streets[shot];
  const arrival = spring({frame: localFrame, fps, config: springConfig});
  const impulse = interpolate(arrival, [0, 1], [1, 0]);
  const direction = (panel?.tilt ?? street?.tilt ?? 1) > 0 ? 1 : -1;
  const drift = interpolate(frame, [0, 104], [0, 14]);
  const accent = cameraAccent(shot, phaseFrame, fps, direction);
  const move = `translate(${direction * impulse * 53 + accent.x}px,${impulse * 58 - drift + accent.y}px) rotate(${accent.roll}deg) scale(${1 - impulse * .09 + accent.scale})`;
  return (
    <div className="stage" style={{transform: move}}>
      {panel && (
        <Prop style={{left: panel.x ?? 40, top: panel.y ?? 505, width: panel.size ?? 1000, height: 911, transform: `rotate(${panel.tilt ?? 0}deg)`}}>
          <UiCards kind={panel.kind} frame={frame} fps={fps} variant={panel.variant} />
        </Prop>
      )}
      {street && (
        <Prop style={{left: 8, top: street.y ?? 486, width: 1064, height: 996, transform: `rotate(${street.tilt ?? 0}deg)`}}>
          <Mechanics kind={street.kind} frame={frame} fps={fps} variant={street.variant} />
        </Prop>
      )}
      {(shot === "character" || shot === "tired") && <CharacterShot frame={frame} fps={fps} sleepy={shot === "tired"} phaseFrame={phaseFrame} />}
      {shot === "shop" && <ShopAction frame={frame} fps={fps} />}
    </div>
  );
};
