import {AbsoluteFill, Audio, interpolate, staticFile, useCurrentFrame, useVideoConfig} from "remotion";
import "@fontsource-variable/montserrat";
import "./style.css";
import {HudOverlay} from "./components/HudOverlay";
import {SceneGraphics} from "./components/SceneGraphics";
import {Subtitles} from "./components/Subtitles";
import {ViceCityBg} from "./components/ViceCityBg";
import {STORY} from "./story";
import {TIMELINE} from "./timeline";

const clamp = {extrapolateLeft: "clamp", extrapolateRight: "clamp"} as const;
const ART_END_FRAME = 104;

export const Gta6ViralVideo = () => {
  const frame = useCurrentFrame();
  const {fps, durationInFrames} = useVideoConfig();
  const closingFrame = frame === durationInFrames - 1;
  const shotIndex = TIMELINE.findIndex((cue) => frame < cue.startFrame + cue.durationInFrames);
  const displayedIndex = closingFrame ? 0 : shotIndex;
  const shot = STORY[displayedIndex];
  const cue = TIMELINE[displayedIndex];
  const displayGlobalFrame = closingFrame ? 0 : frame;
  const localFrame = displayGlobalFrame - cue.startFrame;
  const artFrame = interpolate(localFrame, [0, cue.durationInFrames - 1], [0, ART_END_FRAME], clamp);
  const midpointFrame = cue.midpointFrame - cue.startFrame;
  const phaseFrame = localFrame - midpointFrame;
  const loopReset = shot.shot === "loop"
    ? interpolate(localFrame, [cue.durationInFrames - 16, cue.durationInFrames - 1], [0, 1], clamp)
    : 0;
  const isHook = shot.shot === "hook" || shot.shot === "loop";
  const titleOpacity = isHook ? 1 : interpolate(localFrame, [0, 10], [.68, 1], clamp);
  const wanted = Math.min(5, 1 + Math.floor(displayedIndex / 6)) - Math.floor(4 * loopReset);
  const beatInterval = Math.round(fps * 2.5);
  const phaseLength = phaseFrame < 0 ? midpointFrame : cue.durationInFrames - midpointFrame;
  const frameInPhase = phaseFrame < 0 ? localFrame : phaseFrame;
  const extraBeat = phaseLength > beatInterval + 12 ? frameInPhase - beatInterval : -1;
  const extraBeatOpacity = interpolate(extraBeat, [0, 1, 10], [0, .18, 0], clamp);

  return (
    <AbsoluteFill className="vc-video">
      <ViceCityBg setting={shot.setting} frame={artFrame} fps={fps} />
      <div className="heading" style={{opacity: titleOpacity}}>
        <div className={`heading-main ${isHook ? "heading-hook" : shot.title.length > 21 ? "compact" : ""}`}>
          {isHook ? "GTA 6" : shot.title}
        </div>
        <span className="heading-line" />
        {isHook && (
          <div className="urgent" style={{opacity: localFrame < 6 || localFrame % 21 < 15 ? 1 : .53}}>
            СРОЧНО
          </div>
        )}
      </div>
      <SceneGraphics
        shot={shot.shot}
        frame={artFrame}
        fps={fps}
        phaseFrame={phaseFrame}
        localFrame={localFrame}
        durationInFrames={cue.durationInFrames}
      />
      {extraBeatOpacity > 0 && (
        <AbsoluteFill style={{background: "linear-gradient(125deg, #ff2e93b0, transparent 45%, #00f0ffb0)", opacity: extraBeatOpacity}} />
      )}
      <HudOverlay frame={displayGlobalFrame * (1 - loopReset)} chapter={shot.chapter} wanted={wanted} />
      <Subtitles timings={cue.captions} keyword={shot.keyword} frame={displayGlobalFrame} fps={fps} cyan={displayedIndex % 2 === 1} />
      <Audio src={staticFile("voiceover.mp3")} />
      <Audio src={staticFile("accents.m4a")} />
    </AbsoluteFill>
  );
};
