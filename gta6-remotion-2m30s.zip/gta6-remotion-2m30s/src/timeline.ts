export type CaptionTiming = {
  text: string;
  startFrame: number;
  durationInFrames: number;
};

export type SceneTiming = {
  startFrame: number;
  durationInFrames: number;
  speechStartFrame: number;
  speechEndFrame: number;
  midpointFrame: number;
  captions: readonly CaptionTiming[];
};

export const FPS = 30;
export const AUDIO_DURATION_SECONDS = 150.2040625;

export const TIMELINE: readonly SceneTiming[] = [
  {
    "startFrame": 0,
    "durationInFrames": 233,
    "speechStartFrame": 0,
    "speechEndFrame": 227,
    "midpointFrame": 116,
    "captions": [
      {
        "text": "GTA 6. Первая неделя после выхода.",
        "startFrame": 0,
        "durationInFrames": 96
      },
      {
        "text": "Мой босс звонит в двадцатый раз,",
        "startFrame": 101,
        "durationInFrames": 46
      },
      {
        "text": "пока я делю магазин с аллигатором в Вайс-Сити!",
        "startFrame": 156,
        "durationInFrames": 71
      }
    ]
  },
  {
    "startFrame": 233,
    "durationInFrames": 185,
    "speechStartFrame": 233,
    "speechEndFrame": 410,
    "midpointFrame": 325,
    "captions": [
      {
        "text": "Мы ждали эту игру 13 лет —",
        "startFrame": 233,
        "durationInFrames": 50
      },
      {
        "text": "и за первые же сутки вся планета",
        "startFrame": 293,
        "durationInFrames": 68
      },
      {
        "text": "одновременно ушла на больничный.",
        "startFrame": 361,
        "durationInFrames": 49
      }
    ]
  },
  {
    "startFrame": 418,
    "durationInFrames": 181,
    "speechStartFrame": 418,
    "speechEndFrame": 593,
    "midpointFrame": 508,
    "captions": [
      {
        "text": "Загрузка встала на 99%.",
        "startFrame": 418,
        "durationInFrames": 58
      },
      {
        "text": "Роутер дымится. Перезагружать страшнее, чем бросить гранату.",
        "startFrame": 482,
        "durationInFrames": 111
      }
    ]
  },
  {
    "startFrame": 599,
    "durationInFrames": 150,
    "speechStartFrame": 599,
    "speechEndFrame": 741,
    "midpointFrame": 674,
    "captions": [
      {
        "text": "Офис открылся. Пришёл один сотрудник.",
        "startFrame": 599,
        "durationInFrames": 89
      },
      {
        "text": "И тот за удлинителем.",
        "startFrame": 694,
        "durationInFrames": 47
      }
    ]
  },
  {
    "startFrame": 749,
    "durationInFrames": 125,
    "speechStartFrame": 749,
    "speechEndFrame": 866,
    "midpointFrame": 811,
    "captions": [
      {
        "text": "В школьном чате двадцать пять записок.",
        "startFrame": 749,
        "durationInFrames": 68
      },
      {
        "text": "Почерк у всех один.",
        "startFrame": 823,
        "durationInFrames": 43
      }
    ]
  },
  {
    "startFrame": 874,
    "durationInFrames": 137,
    "speechStartFrame": 874,
    "speechEndFrame": 1005,
    "midpointFrame": 942,
    "captions": [
      {
        "text": "Курьер уже час в пути.",
        "startFrame": 874,
        "durationInFrames": 48
      },
      {
        "text": "Судя по стриму, пиццу повезли по Вайс-Сити.",
        "startFrame": 928,
        "durationInFrames": 77
      }
    ]
  },
  {
    "startFrame": 1011,
    "durationInFrames": 172,
    "speechStartFrame": 1011,
    "speechEndFrame": 1177,
    "midpointFrame": 1097,
    "captions": [
      {
        "text": "Энергетики? Ноль. Лапша? Ноль.",
        "startFrame": 1011,
        "durationInFrames": 86
      },
      {
        "text": "Вот теперь это игра на выживание.",
        "startFrame": 1102,
        "durationInFrames": 75
      }
    ]
  },
  {
    "startFrame": 1183,
    "durationInFrames": 171,
    "speechStartFrame": 1183,
    "speechEndFrame": 1348,
    "midpointFrame": 1268,
    "captions": [
      {
        "text": "В магазине осталась одна коробка.",
        "startFrame": 1183,
        "durationInFrames": 62
      },
      {
        "text": "Открыли. Там пенопласт и чужая надежда.",
        "startFrame": 1251,
        "durationInFrames": 97
      }
    ]
  },
  {
    "startFrame": 1354,
    "durationInFrames": 139,
    "speechStartFrame": 1354,
    "speechEndFrame": 1487,
    "midpointFrame": 1423,
    "captions": [
      {
        "text": "Наконец зашёл в игру.",
        "startFrame": 1354,
        "durationInFrames": 46
      },
      {
        "text": "Мой ужин — пакетик специй из пустой пачки.",
        "startFrame": 1405,
        "durationInFrames": 82
      }
    ]
  },
  {
    "startFrame": 1493,
    "durationInFrames": 164,
    "speechStartFrame": 1493,
    "speechEndFrame": 1651,
    "midpointFrame": 1575,
    "captions": [
      {
        "text": "Джейсон пропустил три сообщения Лусии.",
        "startFrame": 1493,
        "durationInFrames": 77
      },
      {
        "text": "Теперь его ждёт очень короткий разговор.",
        "startFrame": 1576,
        "durationInFrames": 75
      }
    ]
  },
  {
    "startFrame": 1657,
    "durationInFrames": 116,
    "speechStartFrame": 1657,
    "speechEndFrame": 1766,
    "midpointFrame": 1715,
    "captions": [
      {
        "text": "Сначала исчезает машина.",
        "startFrame": 1657,
        "durationInFrames": 45
      },
      {
        "text": "Смотри, вон она. На эвакуаторе.",
        "startFrame": 1707,
        "durationInFrames": 59
      }
    ]
  },
  {
    "startFrame": 1773,
    "durationInFrames": 150,
    "speechStartFrame": 1773,
    "speechEndFrame": 1914,
    "midpointFrame": 1848,
    "captions": [
      {
        "text": "Потом убежище.",
        "startFrame": 1773,
        "durationInFrames": 38
      },
      {
        "text": "Прикладываю ключ. Замок мне отвечает красным крестом.",
        "startFrame": 1817,
        "durationInFrames": 97
      }
    ]
  },
  {
    "startFrame": 1923,
    "durationInFrames": 135,
    "speechStartFrame": 1923,
    "speechEndFrame": 2048,
    "midpointFrame": 1990,
    "captions": [
      {
        "text": "Даже собака ушла с Лусией.",
        "startFrame": 1923,
        "durationInFrames": 54
      },
      {
        "text": "У меня осталась миска. Пустая.",
        "startFrame": 1984,
        "durationInFrames": 64
      }
    ]
  },
  {
    "startFrame": 2058,
    "durationInFrames": 176,
    "speechStartFrame": 2058,
    "speechEndFrame": 2227,
    "midpointFrame": 2146,
    "captions": [
      {
        "text": "Три пропущенных сообщения. Три потери.",
        "startFrame": 2058,
        "durationInFrames": 79
      },
      {
        "text": "Джейсон впервые разблокировал поход пешком.",
        "startFrame": 2143,
        "durationInFrames": 84
      }
    ]
  },
  {
    "startFrame": 2234,
    "durationInFrames": 150,
    "speechStartFrame": 2234,
    "speechEndFrame": 2378,
    "midpointFrame": 2309,
    "captions": [
      {
        "text": "Перед магазином встаёт спорткар.",
        "startFrame": 2234,
        "durationInFrames": 53
      },
      {
        "text": "Один прохожий снимает, второй выписывает штраф.",
        "startFrame": 2292,
        "durationInFrames": 86
      }
    ]
  },
  {
    "startFrame": 2384,
    "durationInFrames": 127,
    "speechStartFrame": 2384,
    "speechEndFrame": 2505,
    "midpointFrame": 2447,
    "captions": [
      {
        "text": "Третий ставит складной стул посреди пробки.",
        "startFrame": 2384,
        "durationInFrames": 71
      },
      {
        "text": "И берёт деньги за проезд.",
        "startFrame": 2460,
        "durationInFrames": 45
      }
    ]
  },
  {
    "startFrame": 2511,
    "durationInFrames": 123,
    "speechStartFrame": 2511,
    "speechEndFrame": 2629,
    "midpointFrame": 2572,
    "captions": [
      {
        "text": "Я сворачиваю на болото.",
        "startFrame": 2511,
        "durationInFrames": 42
      },
      {
        "text": "Там пробка тоже. Из аэролодок.",
        "startFrame": 2557,
        "durationInFrames": 72
      }
    ]
  },
  {
    "startFrame": 2634,
    "durationInFrames": 125,
    "speechStartFrame": 2634,
    "speechEndFrame": 2754,
    "midpointFrame": 2696,
    "captions": [
      {
        "text": "В итоге трафик разрулил мужик с тележкой.",
        "startFrame": 2634,
        "durationInFrames": 71
      },
      {
        "text": "Просто пошёл поперёк.",
        "startFrame": 2713,
        "durationInFrames": 41
      }
    ]
  },
  {
    "startFrame": 2759,
    "durationInFrames": 139,
    "speechStartFrame": 2759,
    "speechEndFrame": 2893,
    "midpointFrame": 2828,
    "captions": [
      {
        "text": "А вот и аллигатор.",
        "startFrame": 2759,
        "durationInFrames": 33
      },
      {
        "text": "Он задел коробку, и она пролетела мимо сканера.",
        "startFrame": 2796,
        "durationInFrames": 97
      }
    ]
  },
  {
    "startFrame": 2898,
    "durationInFrames": 163,
    "speechStartFrame": 2898,
    "speechEndFrame": 3056,
    "midpointFrame": 2979,
    "captions": [
      {
        "text": "Касса пищит. Чек готов.",
        "startFrame": 2898,
        "durationInFrames": 49
      },
      {
        "text": "Из всей очереди он единственный дошёл до оплаты.",
        "startFrame": 2960,
        "durationInFrames": 96
      }
    ]
  },
  {
    "startFrame": 3061,
    "durationInFrames": 138,
    "speechStartFrame": 3061,
    "speechEndFrame": 3193,
    "midpointFrame": 3130,
    "captions": [
      {
        "text": "Клип с аллигатором разлетелся так быстро,",
        "startFrame": 3061,
        "durationInFrames": 65
      },
      {
        "text": "что босс прислал мне мой же ролик.",
        "startFrame": 3132,
        "durationInFrames": 61
      }
    ]
  },
  {
    "startFrame": 3199,
    "durationInFrames": 160,
    "speechStartFrame": 3199,
    "speechEndFrame": 3353,
    "midpointFrame": 3279,
    "captions": [
      {
        "text": "В моей версии игра делает $1 000 000 000 за сутки.",
        "startFrame": 3199,
        "durationInFrames": 102
      },
      {
        "text": "У босса оборот — ноль.",
        "startFrame": 3307,
        "durationInFrames": 46
      }
    ]
  },
  {
    "startFrame": 3359,
    "durationInFrames": 143,
    "speechStartFrame": 3359,
    "speechEndFrame": 3495,
    "midpointFrame": 3430,
    "captions": [
      {
        "text": "Он пишет: срочно зайди в офис.",
        "startFrame": 3359,
        "durationInFrames": 58
      },
      {
        "text": "Через секунду вижу его статус: онлайн.",
        "startFrame": 3421,
        "durationInFrames": 74
      }
    ]
  },
  {
    "startFrame": 3502,
    "durationInFrames": 125,
    "speechStartFrame": 3502,
    "speechEndFrame": 3619,
    "midpointFrame": 3564,
    "captions": [
      {
        "text": "К вечеру весь отдел снова на связи.",
        "startFrame": 3502,
        "durationInFrames": 65
      },
      {
        "text": "Созвон теперь под пальмой.",
        "startFrame": 3572,
        "durationInFrames": 47
      }
    ]
  },
  {
    "startFrame": 3627,
    "durationInFrames": 132,
    "speechStartFrame": 3627,
    "speechEndFrame": 3751,
    "midpointFrame": 3693,
    "captions": [
      {
        "text": "День седьмой. Я наконец-то готов на работу.",
        "startFrame": 3627,
        "durationInFrames": 92
      },
      {
        "text": "Ещё минуту.",
        "startFrame": 3725,
        "durationInFrames": 26
      }
    ]
  },
  {
    "startFrame": 3759,
    "durationInFrames": 138,
    "speechStartFrame": 3759,
    "speechEndFrame": 3891,
    "midpointFrame": 3828,
    "captions": [
      {
        "text": "На совещании одна повестка.",
        "startFrame": 3759,
        "durationInFrames": 55
      },
      {
        "text": "Кто оставил нас в игре без машины?",
        "startFrame": 3819,
        "durationInFrames": 72
      }
    ]
  },
  {
    "startFrame": 3897,
    "durationInFrames": 149,
    "speechStartFrame": 3897,
    "speechEndFrame": 4041,
    "midpointFrame": 3971,
    "captions": [
      {
        "text": "Мы нашли машину. За рулём начальник.",
        "startFrame": 3897,
        "durationInFrames": 84
      },
      {
        "text": "У него пять звёзд и пицца.",
        "startFrame": 3985,
        "durationInFrames": 56
      }
    ]
  },
  {
    "startFrame": 4046,
    "durationInFrames": 138,
    "speechStartFrame": 4046,
    "speechEndFrame": 4177,
    "midpointFrame": 4115,
    "captions": [
      {
        "text": "До офиса две минуты.",
        "startFrame": 4046,
        "durationInFrames": 40
      },
      {
        "text": "Маршрут перестроен. Финиш — очередь за лапшой.",
        "startFrame": 4090,
        "durationInFrames": 87
      }
    ]
  },
  {
    "startFrame": 4184,
    "durationInFrames": 134,
    "speechStartFrame": 4184,
    "speechEndFrame": 4312,
    "midpointFrame": 4251,
    "captions": [
      {
        "text": "И тут мне звонит босс.",
        "startFrame": 4184,
        "durationInFrames": 50
      },
      {
        "text": "Помнишь, с чего начались эти двадцать пропущенных?",
        "startFrame": 4239,
        "durationInFrames": 73
      }
    ]
  },
  {
    "startFrame": 4318,
    "durationInFrames": 189,
    "speechStartFrame": 4318,
    "speechEndFrame": 4502,
    "midpointFrame": 4412,
    "captions": [
      {
        "text": "А ты выйдешь на работу в день релиза?",
        "startFrame": 4318,
        "durationInFrames": 55
      },
      {
        "text": "Пиши в комментариях.",
        "startFrame": 4378,
        "durationInFrames": 30
      },
      {
        "text": "А теперь посмотри, с чего всё началось...",
        "startFrame": 4415,
        "durationInFrames": 87
      }
    ]
  }
];
